package GestorTexto;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import Clases.Equipo;
import Clases.Patrocinador;

public class GestorTexto {
    String rutaArchivo;

    public GestorTexto(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public ArrayList<Equipo> getEquipos() {
        return transformarLineas(leerArchivoMemoria());
    }

    private ArrayList<String> leerArchivoMemoria() {
        ArrayList<String> lineas = new ArrayList<>();
        LecturaTexto lectura = new LecturaTexto(rutaArchivo);

        lectura.abrirFichero();

        String linea = lectura.leerLinea();
        do {
            lineas.add(linea);

        } while ((linea = lectura.leerLinea()) != null);

        lectura.cerrarFichero();

        return lineas;
    }

    private ArrayList<Equipo> transformarLineas(ArrayList<String> lineas) {
        ArrayList<Equipo> equipos = new ArrayList<>();
        Equipo equipo;

        for (int i = 0; i < lineas.size(); i++) {
            String linea = lineas.get(i);
            String[] informacion = linea.split(",");
            equipo = new Equipo();

            equipo.setCodigo(informacion[0]);
            equipo.setNombre(informacion[1]);
            equipo.setPatrocinadores(transInfoPatrocinadores(informacion[2]));

            equipos.add(equipo);

        }

        return equipos;
    }

    private ArrayList<Patrocinador> transInfoPatrocinadores(String linea) {
        Patrocinador patrocinador;
        String[] patrocinadores = linea.split(";");

        ArrayList<Patrocinador> listPatrocinadores = new ArrayList<>();

        for (int i = 0; i < patrocinadores.length; i++) {
            patrocinador = new Patrocinador();
            String[] infoPatrocinadorIndividual = patrocinadores[i].split("\\|");

            patrocinador.setNombre(transformarNombrePatrocinador(infoPatrocinadorIndividual[0]));
            patrocinador.setCantidad(Float.parseFloat(infoPatrocinadorIndividual[1]));
            patrocinador.setFecha(LocalDate.parse(infoPatrocinadorIndividual[2]));

            listPatrocinadores.add(patrocinador);

        }

        return listPatrocinadores;
    }

    private String transformarNombrePatrocinador(String linea) {

        linea = linea.replaceAll("Patrocinadores:", "");
        linea = linea.replaceAll(",", "");
        System.out.println(linea.trim());

        return linea.trim();
    }

}
