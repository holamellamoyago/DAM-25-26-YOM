package GestorTexto;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LecturaTexto extends Archivo {
    BufferedReader reader; 

    public LecturaTexto(String ruta) {
        super(ruta);
    }

    @Override
    public void abrirFichero()  {
        try {
            reader = new BufferedReader(new FileReader(fichero))    ;
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void cerrarFichero() {
        try {
            reader.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public String leerLinea(){
        String linea = null;

        try {
            linea = reader.readLine();
        } catch (Exception e) {
        }

        return linea;
    }

    
}
