import java.util.ArrayList;

import Clases.Equipo;
import Clases.TipoValidacion;
import GestorDOM.GestorEquiposDOM;
import GestorTexto.GestorTexto;

public class App {
    public static void main(String[] args) throws Exception {
        GestorTexto gestorTexto = new GestorTexto("Archivos/Equipos.txt");
        ArrayList<Equipo> equipos = gestorTexto.getEquipos();

        GestorEquiposDOM gestorDom = new GestorEquiposDOM("Archivos/Equipos20.xml", TipoValidacion.NO_VALIDAR);
        gestorDom.escribirEquipos(equipos, "Archivos/Equipos20.xml");

    }
}
