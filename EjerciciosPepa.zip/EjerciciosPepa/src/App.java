import Clases.TipoValidacion;
import GestorDOM.GestorEquiposDOM;
import GestorJAXB.GestorEquiposJAXB;
import GestorSAX.GestorEquiposSAX;
import GestorSTAX.GestorEquiposSTAX;
import GestorTexto.GestorTexto;
import GestorXPATH.GestorEquiposXPATH;

public class App {
    public static void main(String[] args) throws Exception {
        String equiposTXT = "Archivos/Equipos.txt";
        String equiposXML = "Archivos/Equipos22.xml";

        GestorTexto gestorTexto = new GestorTexto(equiposTXT);
        System.out.println(gestorTexto.getEquipos());

        GestorEquiposDOM gestorDom = new GestorEquiposDOM(equiposXML, TipoValidacion.NO_VALIDAR);
        gestorDom.escribirEquipos(gestorTexto.getEquipos());

        GestorEquiposSAX gestorEquiposSAX = new GestorEquiposSAX(equiposXML, TipoValidacion.NO_VALIDAR);
        System.out.println(gestorEquiposSAX.getEquipos());

        GestorEquiposSTAX gestorEquiposSTAX = new GestorEquiposSTAX(equiposXML, TipoValidacion.NO_VALIDAR);
        System.out.println("\n" + gestorEquiposSTAX.getEquipos());

        System.out.println();

        GestorEquiposJAXB gestorEquiposJAXB = new GestorEquiposJAXB(equiposXML);
        gestorEquiposJAXB.leerEquipos();

        System.out.println();
        GestorEquiposXPATH gestorEquiposXPATH = new GestorEquiposXPATH(equiposXML);
        gestorEquiposXPATH.getEquipo("//Equipo[@codigo=\"E10\"]");
        

        
    }
}
