import GestorDOM.GestorEquiposDOM;
import GestorTexto.GestorTexto;
import GestorTexto.LecturaTexto;

public class App {
    public static void main(String[] args) throws Exception {
        GestorTexto gestorTexto = new GestorTexto("Archivos/Equipos.txt");
        System.out.println(gestorTexto.getEquipos());

        GestorEquiposDOM gestorDom;

        
    }
}
