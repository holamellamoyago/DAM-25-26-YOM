package GestorJAXB;

import Clases.Equipos;

public class GestorEquiposJAXB {
    String rutaArchivo;

    public GestorEquiposJAXB(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public Equipos leerEquipos(){
        Equipos equipos =  XMLJAXBUtils.unmarshall(Equipos.class, rutaArchivo);
        System.out.println(equipos);
        return equipos;
    }

    
}
 