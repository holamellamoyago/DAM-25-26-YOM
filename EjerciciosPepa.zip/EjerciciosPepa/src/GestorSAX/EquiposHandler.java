package GestorSAX;

import java.time.LocalDate;
import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import Clases.Equipo;
import Clases.Patrocinador;

public class EquiposHandler extends DefaultHandler {
    private Equipo e;
    private Patrocinador p;

    private String contenidoElemento;

    private ArrayList<Equipo> equipos = new ArrayList<>();
    private ArrayList<Patrocinador> patrocinadores = new ArrayList<>();

    public EquiposHandler() {
    }

    @Override
    public void startDocument() throws SAXException {
        super.startDocument();
    }

    @Override
    public void endDocument() throws SAXException {
        super.endDocument();
    }

    @Override
    public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
        System.out.println("Leyendo el elemento: " + qName);
        switch (qName) {
            case "Equipo":
                e = new Equipo();
                getAtributosEquipo(attributes);
                break;

            case "Patrocinador":
                p = new Patrocinador();
                getAtributosPatrocinador(attributes);
                break;

            default:
                break;
        }
    }

    @Override
    public void endElement(String uri, String localName, String qName) throws SAXException {
        System.out.println("Cerrando el elemento: " + qName);
        switch (qName) {
            case "Nombre":
                e.setNombre(contenidoElemento);
                break;
            case "Equipo":
                e.setPatrocinadores(new ArrayList<>(patrocinadores));
                equipos.add(e);

                patrocinadores.clear();
                e = new Equipo();

                break;
            case "Patrocinador":
                System.out.println("*** guardando el " + p);
                patrocinadores.add(p);
                p = new Patrocinador();
                break;

            default:
                break;
        }
    }

    @Override
    public void characters(char[] ch, int start, int length) throws SAXException {
        contenidoElemento = String.valueOf(ch, start, length);
    }

    private void getAtributosEquipo(Attributes attributes) {
        for (int i = 0; i < attributes.getLength(); i++) {
            String nombre = attributes.getQName(i);
            System.out.println("** Leyendo atributo: " + nombre);
            String valor = attributes.getValue(nombre);

            switch (nombre) {
                case "codigo":
                    e.setCodigo(valor);
                default:
                    break;
            }
        }
    }

    private void getAtributosPatrocinador(Attributes attributes) {

        for (int i = 0; i < attributes.getLength(); i++) {
            String nombreAtributo = attributes.getQName(i);
            String valorAtributo = attributes.getValue(nombreAtributo);

            System.out.println("Leyendo el atributo " + nombreAtributo + " " + valorAtributo);

            switch (nombreAtributo) {
                case "Cantidad":
                    Float valor = Float.parseFloat(valorAtributo);
                    p.setCantidad(valor);
                    break;

                case "Fecha":
                    LocalDate fecha = LocalDate.parse(valorAtributo);
                    p.setFecha(fecha);
                    break;

                case "Nombre":
                    String nombre = valorAtributo;
                    p.setNombre(nombre);
                    break;

                default:
                    break;
            }
        }
    }

    public ArrayList<Equipo> getEquipos() {
        return equipos;
    }
}
