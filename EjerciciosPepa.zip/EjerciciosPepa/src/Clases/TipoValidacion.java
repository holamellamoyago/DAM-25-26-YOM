package Clases;

public enum TipoValidacion {
    NO_VALIDAR,
    DTD,
    XSD
}
