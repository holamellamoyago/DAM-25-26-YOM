package Clases;

import java.time.LocalDate;
import jakarta.xml.bind.annotation.XmlAttribute;


import jakarta.xml.bind.annotation.*;
import jakarta.xml.bind.annotation.adapters.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class Patrocinador {

    @XmlAttribute(name = "Nombre", required = true)
    private String nombre;

    @XmlAttribute(name = "Cantidad", required = true)
    private float cantidad;

    @XmlAttribute(name = "Fecha", required = true)
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate fecha;

    public Patrocinador(String nombre, float cantidad, LocalDate fecha) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.fecha = fecha;
    }

    
    public Patrocinador() {
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getCantidad() {
        return cantidad;
    }

    public void setCantidad(float cantidad) {
        this.cantidad = cantidad;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }


    @Override
    public String toString() {
        return "\n    Patrocinador " + nombre + ", " + cantidad + ", " + fecha;
    }

    

    
}
