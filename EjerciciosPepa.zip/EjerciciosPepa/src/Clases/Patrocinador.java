package Clases;

import java.time.LocalDate;

public class Patrocinador {
    private String nombre;
    private float cantidad;
    private LocalDate fecha;

    public Patrocinador(String nombre, float cantidad, LocalDate fecha) {
        this.nombre = nombre;
        this.cantidad = cantidad;
        this.fecha = fecha;
    }

    
    public Patrocinador() {
    }


    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public float getCantidad() {
        return cantidad;
    }

    public void setCantidad(float cantidad) {
        this.cantidad = cantidad;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        this.fecha = fecha;
    }


    @Override
    public String toString() {
        return "\n    Patrocinador " + nombre + ", " + cantidad + ", " + fecha;
    }

    

    
}
