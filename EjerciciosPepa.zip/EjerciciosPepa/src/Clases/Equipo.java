package Clases;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Equipo {
    private String codigo, nombre;
    private ArrayList<Patrocinador> patrocinadores;

    public Equipo(String codigo, String nombre, ArrayList<Patrocinador> patrocinadores) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.patrocinadores = patrocinadores;
    }

    public Equipo(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
        patrocinadores = new ArrayList<>();
    }

    

    public Equipo() {
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Patrocinador> getPatrocinadores() {
        return patrocinadores;
    }

    public void setPatrocinadores(ArrayList<Patrocinador> patrocinadores) {
        this.patrocinadores = patrocinadores;
    }

    @Override
    public String toString() {
        return "\nEquipo " + nombre +  "(" + codigo + "), Patrocinadores=" + patrocinadores;
    }

    
    

}
