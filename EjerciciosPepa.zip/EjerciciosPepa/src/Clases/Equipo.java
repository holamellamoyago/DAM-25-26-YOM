package Clases;

import java.util.ArrayList;

import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElementWrapper;
import jakarta.xml.bind.annotation.*;
import jakarta.xml.bind.annotation.adapters.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class Equipo {

    @XmlAttribute(name = "codigo", required = true)
    private String codigo;

    @XmlElement(name = "Nombre")
    private String nombre;

    @XmlElementWrapper(name = "Patrocinadores")
    @XmlElement(name = "Patrocinador")
    private ArrayList<Patrocinador> patrocinadores;

    public Equipo(){
        patrocinadores = new ArrayList<>();
    }

    public Equipo(String codigo, String nombre, ArrayList<Patrocinador> patrocinadores) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.patrocinadores = patrocinadores;
    }

    public Equipo(String codigo, String nombre) {
        this.codigo = codigo;
        this.nombre = nombre;
        patrocinadores = new ArrayList<>();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Patrocinador> getPatrocinadores() {
        return patrocinadores;
    }

    public void setPatrocinadores(ArrayList<Patrocinador> patrocinadores) {
        this.patrocinadores = patrocinadores;
    }

    @Override
    public String toString() {
        return "\nEquipo " + nombre +  "(" + codigo + "), Patrocinadores=" + patrocinadores;
    }

    

    
    

}
