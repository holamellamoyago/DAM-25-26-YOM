package Clases;

import java.util.ArrayList;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "Equipos")
@XmlAccessorType(XmlAccessType.FIELD)
public class Equipos {

    @XmlElement(name = "Equipo")
    private ArrayList<Equipo> equipos;

    public Equipos() {
        equipos = new ArrayList<>();
    }

    public ArrayList<Equipo> getEquipos() {
        return equipos;
    }

    public void setEquipos(ArrayList<Equipo> equipos) {
        this.equipos = equipos;
    }

    @Override
    public String toString() {
        return "\nEquipos (JAXB): " + equipos;
    }

}