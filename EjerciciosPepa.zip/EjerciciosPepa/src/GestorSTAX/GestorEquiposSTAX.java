package GestorSTAX;

import java.time.LocalDate;
import java.util.ArrayList;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import Clases.Equipo;
import Clases.Patrocinador;
import Clases.TipoValidacion;

public class GestorEquiposSTAX {
    private String rutaArchivo;
    TipoValidacion tipoValidacion;

    private XMLStreamReader reader;

    public GestorEquiposSTAX(String rutaArchivo, TipoValidacion tipoValidacion) {
        this.rutaArchivo = rutaArchivo;
        this.tipoValidacion = tipoValidacion;

        reader = ConfiguracionSTAX.crearStreamReader(rutaArchivo, tipoValidacion);
    }

    public ArrayList<Equipo> getEquipos() {
        ArrayList<Equipo> equipos = new ArrayList<>();
        ArrayList<Patrocinador> patrocinadores = new ArrayList<>();

        Equipo e = new Equipo();
        Patrocinador p;

        try {
            while (reader.hasNext()) {
                int tipo = reader.next();
                
                switch (tipo) {
                    case XMLStreamReader.START_ELEMENT:
                        switch (XMLSTAXUtils.obtenerNombreEtiqueta(reader)) {
                            case "Equipo":
                                e = new Equipo();
                                e.setCodigo(XMLSTAXUtils.leerAtributo(reader, "codigo"));
                                break;
                            case "Nombre":
                                e.setNombre(XMLSTAXUtils.leerTexto(reader));
                                break;

                            case "Patrocinador":
                                p = new Patrocinador();
                                p.setNombre(XMLSTAXUtils.leerAtributo(reader, "Nombre"));
                                p.setCantidad(Float.parseFloat(XMLSTAXUtils.leerAtributo(reader, "Cantidad")));
                                p.setFecha(LocalDate.parse(XMLSTAXUtils.leerAtributo(reader, "Fecha")));

                                patrocinadores.add(p);
                            
                            default:
                                break;
                        }    


                        break;

                    case XMLStreamReader.END_ELEMENT:
                        switch (XMLSTAXUtils.obtenerNombreEtiqueta(reader)) {
                            case "Equipo":
                                e.setPatrocinadores(patrocinadores);
                                equipos.add(e);

                                patrocinadores = new ArrayList<>();
                                break;
                        
                            default:
                                break;
                        }
                        break;
                
                    default:
                        break;
                }
            }

            return equipos;

        } catch (XMLStreamException a) {
            throw new ArithmeticException(a.toString());
        }
    }

}
