package GestorXPATH;

import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Document;
import org.xml.sax.SAXException;

public class XMLXPATHUtils {
    public static Document getDocument(String rutaArchivo) {
        try {
            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(rutaArchivo);

            return document;
        } catch (SAXException | IOException | ParserConfigurationException e) {
            throw new ArithmeticException(e.toString());
        }
    }

    public static XPath getXPath() {
        return XPathFactory.newInstance().newXPath();

    }

}
