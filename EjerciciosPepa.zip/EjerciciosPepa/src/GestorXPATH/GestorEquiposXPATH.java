package GestorXPATH;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpression;
import javax.xml.xpath.XPathExpressionException;

import org.w3c.dom.Document;
import org.w3c.dom.*;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import Clases.Equipo;

public class GestorEquiposXPATH {
    private Document document;

    public GestorEquiposXPATH(String rutaArchivo) {
        this.document = XMLXPATHUtils.getDocument(rutaArchivo);
    }

    public Equipo getEquipo(String expresion) {
        try {
            XPath xPath = XMLXPATHUtils.getXPath();
            XPathExpression expresionXPath = xPath.compile(expresion);

            NodeList nodeList = (NodeList) expresionXPath.evaluate(document, XPathConstants.NODESET);

            for (int i = 0; i < nodeList.getLength(); i++) {
                Element element = (Element) nodeList.item(i);
                System.out.println(element.getTextContent().trim());
            }

        } catch (XPathExpressionException e) {
            e.printStackTrace();
        }

        return null;

    }

}
