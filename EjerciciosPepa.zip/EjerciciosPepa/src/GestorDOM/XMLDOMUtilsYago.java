package GestorDOM;

import java.io.File;
import java.io.FileWriter;

import javax.xml.XMLConstants;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import Clases.TipoValidacion;
import ManejadorErrorres.ExcepcionXML;
import ManejadorErrorres.SimpleErrorHandler;

public class XMLDOMUtilsYago {

    static final String JAXP_SCHEMA_LANGUAGE = "http://java.sun.com/xml/jaxp/properties/schemaLanguage";
    static final String W3C_XML_SCHEMA = "http://www.w3.org/2001/XMLSchema";

    public static Document cargarDocumentoXML(String rutaFichero, TipoValidacion validacion) {
        try {

            if (!new File(rutaFichero).exists()) {
                System.out.println("\nEl archivo no existe, se crea uno nuevo");
                return crearNuevoDocumentoXML();

            }

            // 1. Crear y configurar la factoría
            DocumentBuilderFactory dbf = configurarFactory(validacion);

            // Crear el parser
            DocumentBuilder db = dbf.newDocumentBuilder();

            // Establecer un mensaje del manejador de errores
            if (validacion != TipoValidacion.NO_VALIDAR) {
                db.setErrorHandler(new SimpleErrorHandler());
            }

            // Cargar el documento en memoria
            Document documento = db.parse(new File(rutaFichero));

            // El getDocumentElement es para conseguir para la raiz del documento
            documento.getDocumentElement().normalize();

            return documento;

        } catch (Exception e) {
            throw new ExcepcionXML("Error de lectura en el XML");
        }
    }

    public static Document crearNuevoDocumentoXML() {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.newDocument();
            return doc;
        } catch (Exception e) {
            throw new ExcepcionXML("Error al crear nuevo documento XML");
        }
    }

    private static DocumentBuilderFactory configurarFactory(TipoValidacion validacion) {
        DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();

        switch (validacion) {
            case DTD -> {
                dbf.setValidating(true);
                dbf.setIgnoringElementContentWhitespace(true);
                dbf.setIgnoringComments(true);
            }

            case XSD -> {
                dbf.setNamespaceAware(true);
                dbf.setIgnoringElementContentWhitespace(true);
                dbf.setValidating(true);
                dbf.setAttribute(JAXP_SCHEMA_LANGUAGE, XMLConstants.W3C_XML_SCHEMA_NS_URI);
            }

            case NO_VALIDAR -> {
                dbf.setValidating(false);
            }
        }

        return dbf;
    }

    public static void guardarDocumentoXML(Document doc, String rutaDestino, String rutaValidacion) {
        try {
            TransformerFactory factory = TransformerFactory.newInstance();

            Transformer transformer = factory.newTransformer();

            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, rutaValidacion);
            // transformer.setOutputProperty(OutputKeys.INDENT, "yes" );
            // transformer.setOutputProperty("(http://xml.apache.org/xslt) indent-amount",
            // "4");

            doc.getDocumentElement().normalize();

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new FileWriter(rutaDestino));
            transformer.transform(source, result);

        } catch (Exception e) {
            throw new ExcepcionXML("Error al guardar");
        }
    }

    public static Element addElement(Document doc, String nombre, Element padre) {
        Element elemento = doc.createElement(nombre);
        // Text texto = doc.createTextNode(valor);

        padre.appendChild(elemento);
        // elemento.appendChild(texto);

        return elemento;
    }

    public static Attr addAtributo(Document doc, String nombre, String valor, Element elemento) {
        Attr attrib = doc.createAttribute(nombre);
        attrib.setValue(valor);
        elemento.setAttributeNode(attrib);

        return attrib;
    }

    public static void modificarValorElemento(Element elemento, Object valor) {
        elemento.setTextContent(String.valueOf(valor));
    }

}