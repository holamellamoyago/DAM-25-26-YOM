package GestorDOM;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;

import javax.swing.event.DocumentEvent;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import Clases.Equipo;
import Clases.Patrocinador;
import Clases.TipoValidacion;

public class GestorEquiposDOM {
    private String rutaArchivo;
    private TipoValidacion tipoValidacion;

    public GestorEquiposDOM(String rutaArchivo, TipoValidacion tipoValidacion) {
        this.rutaArchivo = rutaArchivo;
        this.tipoValidacion = tipoValidacion;
    }

    public void escribirEquipos(ArrayList<Equipo> equipos) {
        Document document = XMLDOMUtils.crearDocumentNuevo();
        Element documentoPadre = XMLDOMUtils.crearElementoRaiz(document, "Equipos");

        for (int i = 0; i < equipos.size(); i++) {
            Equipo e = equipos.get(i);

            Element equipoXML = XMLDOMUtils.addElement(document, "Equipo", documentoPadre);
            XMLDOMUtils.addAtributo(document, "codigo", e.getCodigo(), equipoXML);

            Element elementNombre = XMLDOMUtils.addElement(document, "Nombre", equipoXML);
            XMLDOMUtils.addTexto(elementNombre, e.getNombre());

            Element patrocinadores = XMLDOMUtils.addElement(document, "Patrocinadores", equipoXML);
            
            for (int j = 0; j < e.getPatrocinadores().size(); j++) {
                Patrocinador p = e.getPatrocinadores().get(j);
                Element patrocinadorXML = XMLDOMUtils.addElement(document, "Patrocinador", patrocinadores);
                XMLDOMUtils.addAtributo(document, "Fecha", String.valueOf(p.getFecha()), patrocinadorXML);
                XMLDOMUtils.addAtributo(document, "Cantidad", String.valueOf(p.getCantidad()), patrocinadorXML);
                XMLDOMUtils.addAtributo(document, "Nombre", String.valueOf(p.getNombre()), patrocinadorXML);


            }
        }

        document.appendChild(documentoPadre);
        XMLDOMUtils.guardarDocumentoXML(document, rutaArchivo);

        System.out.println("\nDocumento creado correctamente");
    }

}
