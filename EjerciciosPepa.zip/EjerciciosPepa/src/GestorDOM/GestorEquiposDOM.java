package GestorDOM;

import java.util.ArrayList;

import org.w3c.dom.Document;
import org.w3c.dom.Element;

import Clases.Equipo;
import Clases.TipoValidacion;

public class GestorEquiposDOM {
    private String rutaArchivo;
    private TipoValidacion tipoValidacion;

    private Document document;

    public GestorEquiposDOM(String rutaArchivo, TipoValidacion tipoValidacion) {
        this.rutaArchivo = rutaArchivo;
        this.tipoValidacion = tipoValidacion;
    }

    public void escribirEquipos(ArrayList<Equipo> equipos, String rutaDestino) {
        document = XMLDOMUtilsYago.cargarDocumentoXML(rutaArchivo, tipoValidacion);
        Element documentElement = document.getDocumentElement();

        if (documentElement == null) {
            document.appendChild(document.createElement("Equipos"));
        }

        documentElement = document.getDocumentElement();
        for (int i = 0; i < equipos.size(); i++) {
            Equipo equipo = equipos.get(i);
            Element elementoEquipo = XMLDOMUtilsYago.addElement(document, "Equipo",
                    documentElement);

            XMLDOMUtilsYago.addAtributo(document, "codigo", equipo.getCodigo(),
                    elementoEquipo);

            Element elementoNombre = XMLDOMUtilsYago.addElement(document, "nombre",
                    elementoEquipo);
            XMLDOMUtilsYago.modificarValorElemento(elementoNombre, equipo.getNombre());

        }

        XMLDOMUtilsYago.guardarDocumentoXML(document, rutaDestino, "");

    }

}
