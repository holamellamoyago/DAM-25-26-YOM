package GestorDOM;

import Clases.TipoValidacion;

public class GestorEquiposDOM {
    private String rutaArchivo;
    private TipoValidacion tipoValidacion;

    public GestorEquiposDOM(String rutaArchivo, TipoValidacion tipoValidacion) {
        this.rutaArchivo = rutaArchivo;
        this.tipoValidacion = tipoValidacion;
    }

    public void escribirEquipos() {
        // TODO Termianr
        XMLDOMUtils.cargarDocumentoXML(rutaArchivo, tipoValidacion);
    }

}
