<?php

class Validar
{
    static function esEntero($num, $permitirVacio = false): bool
    {
        if ($permitirVacio) if ($num == '') return true;
        return preg_match('/^\d+$/', $num);
    }
}
