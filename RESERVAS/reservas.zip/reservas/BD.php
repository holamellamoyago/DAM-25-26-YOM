<?php
// BD.php
require_once 'validar.php';

class BD extends PDO
{
    private const SERVIDOR_BD = 'localhost';
    private const USUARIO_BD = 'root';
    private const PASSWORD_BD = '';

    // Cambié nombre de bd
    private const BD = 'reservas';
    private const DSN = 'mysql:host=' . self::SERVIDOR_BD . ';dbname=' . self::BD . ';charset=utf8mb4';

    public function __construct()
    {
        parent::__construct(self::DSN, self::USUARIO_BD, self::PASSWORD_BD);
    }

    function getReservasHabitacion($codCliente = ''): array
    {
        if ($codCliente == '')
            $WHERE = '';
        else if (!Validar::esEntero($codCliente))
            return [];
        else
            $WHERE = "WHERE reservas.idHabitacion=$codCliente";
        $sql = "SELECT  reservas.codReserva AS codReserva,
                        reservas.nombre AS nombre,
                        reservas.dia AS dia,
                        reservas.numDias AS numDias,
                        habitaciones.idHabitacion AS idHabitacion,
                        habitaciones.nombre AS nombreProvincia
                    FROM reservas 
                    LEFT JOIN habitaciones ON reservas.idHabitacion=habitaciones.idHabitacion 
                    $WHERE ORDER BY codReserva";

        if ($cursor = $this->query($sql))
            return $cursor->fetchAll(PDO::FETCH_OBJ);

        return [];
    }


    function getReservas($codCliente = ''): array
    {
        if ($codCliente == '')
            $WHERE = '';
        else if (!Validar::esEntero($codCliente))
            return [];
        else
            $WHERE = "WHERE reservas.codReserva=$codCliente";
        $sql = "SELECT  reservas.codReserva AS codReserva,
                        reservas.nombre AS nombre,
                        reservas.dia AS dia,
                        reservas.numDias AS numDias
                    FROM reservas 
                    $WHERE ORDER BY codReserva";

        if ($cursor = $this->query($sql))
            return $cursor->fetchAll(PDO::FETCH_OBJ);

        return [];
    }


    // Coger todas las habitaciones 
    function getHabitaciones($codCliente = ''): array
    {
        if ($codCliente == '')
            $WHERE = '';
        else if (!Validar::esEntero($codCliente))
            return [];
        else
            $WHERE = "WHERE idHabitacion=$codCliente";
        $sql = "SELECT
                        idHabitacion,
                        nombre
                    FROM habitaciones
                    -- LEFT JOIN habitaciones ON reservas.idHabitacion=habitaciones.idHabitacion 
                    $WHERE 
                    ORDER BY idHabitacion";

        if ($cursor = $this->query($sql))
            return $cursor->fetchAll(PDO::FETCH_OBJ);

        return [];
    }

    // Cambio para poder coger cada reserva individualmente
    function getReserva($codCliente): object | null
    {
        $clientes = $this->getReservas($codCliente);
        if (empty($clientes)) return null;
        return $clientes[0];
    }

    function getHabitacion($codCliente): object | null
    {
        $clientes = $this->getHabitaciones($codCliente);
        if (empty($clientes)) return null;
        return $clientes[0];
    }

    function touchReserva($idHabitacion, $nombre, $dia, $numDias): int
    {

        $sql = "INSERT INTO reservas (idHabitacion, nombre, dia, numDias) VALUES
                        (:idHabitacion,:nombre,:dia,:numDias)";

        $stmt = $this->prepare($sql);
        $stmt->bindParam(":idHabitacion", $idHabitacion);
        $stmt->bindParam(":nombre", $nombre);
        $stmt->bindParam(":dia", $dia);
        $stmt->bindParam(":numDias", $numDias);

        try {
            $stmt->execute();
            $codReserva = $this->lastInsertId();
        } catch (PDOException $ex) {
            return -1;
        }

        return $codReserva;
    }

    function eliminarReserva($codCliente): bool
    {
        if (!Validar::esEntero($codCliente)) return false;
        $sql = "DELETE FROM reservas WHERE codReserva=$codCliente";
        if (!$this->query($sql)) return false;
        return true;
    }

}

try {
    $bd = new BD();
} catch (PDOException $ex) {
    exit('No se ha podido conectar con la BD');
}
