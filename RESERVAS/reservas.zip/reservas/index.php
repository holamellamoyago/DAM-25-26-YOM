<?php
// index.php
require 'Router.php';
require 'controladores/ClienteControlador.php';
require 'BD.php';

header('Content-Type: application/json');
$router = new Router();
$controlador = new ClienteControlador();

// Cambio esto por reservas 
$router->get('/reservas', function () use ($controlador, $bd) {
    return $controlador->getAll($bd);
});

// Cambio esto por habitaciones 
$router->get('/habitaciones', function () use ($controlador, $bd) {
    return $controlador->getAllHabitaciones($bd);
});

// $router->get('/clientes', function () use ($controlador, $bd) {
//     return $controlador->getAll($bd);
// });

// Cambio esto para poder coger cada reserva de una RESERVA concreta
$router->get('/reserva-habitacion/(\d+)', function ($params) use ($controlador, $bd) {
    $codCliente = $params[1];
    return $controlador->getReservaHabitacion($bd, $codCliente);
});

// Cambio esto para poder coger cada reserva de una HABITACOION concreta
$router->get('/habitacion/(\d+)', function ($params) use ($controlador, $bd) {
    $codCliente = $params[1];
    return $controlador->getHabitacion($bd, $codCliente);
});

// Creo la función para mirar una reserva concreta por su código
$router->get('/reserva/(\d+)', function ($params) use ($controlador, $bd) {
    $codCliente = $params[1];
    return $controlador->getReserva($bd, $codCliente);
});

// no me dió tiempo a terminarla
$router->delete('/reserva/(\d+)', function ($params) use ($controlador, $bd) {
    $codCliente = $params[1];
    return $controlador->delete($bd, $codCliente);
});


// CAMBIO EL POST DE RESERVAS
$router->post('/reservas', function () use ($controlador, $bd) {
    $body = file_get_contents('php://input');
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (str_contains($contentType, 'application/json'))
        $reserva = json_decode($body, false);
    else {
        parse_str($body, $datos);
        $reserva = (object)$datos;
    }
    return $controlador->postReserva($bd, $reserva);
});

$router->dispatch($_SERVER['REQUEST_METHOD'], $_SERVER['PATH_INFO'] ?? '/');
