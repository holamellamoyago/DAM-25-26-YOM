<?php

class ClienteControlador
{
    // Tuve que cambiar el nombre de la funcion
    public function getAll($bd)
    {
        return ['body' => json_encode($bd->getReservasHabitacion())];
    }

    // Tuve que cambiar el nombre de la funcion de habitaciones
    public function getAllHabitaciones($bd)
    {
        return ['body' => json_encode($bd->getHabitaciones())];
    }

    // Cojo reservas
    public function getReservaHabitacion($bd, $idHabitacion)
    {
        if ($habitacion = $bd->getReservasHabitacion($idHabitacion))
            return ['body' => json_encode($habitacion)];
        return ['status' => 404, 'body' => json_encode(['message' => 'Cliente Not Found'])];
    }

    public function getHabitacion($bd, $idHabitacion)
    {
        if ($habitacion = $bd->getHabitacion($idHabitacion))
            return ['body' => json_encode($habitacion)];
        return ['status' => 404, 'body' => json_encode(['message' => 'Cliente Not Found'])];
    }

    public function getReserva($bd, $idHabitacion)
    {
        if ($habitacion = $bd->getReserva($idHabitacion))
            return ['body' => json_encode($habitacion)];
        return ['status' => 404, 'body' => json_encode(['message' => 'Cliente Not Found'])];
    }

    public function postReserva($bd, $c)
    {
        $codCliente = $bd->touchReserva($c->idHabitacion, $c->nombre, $c->dia, $c->numDias);

        if ($codCliente < 0)
            return ['status' => 422, 'body' => json_encode(['message' => 'Datos incorrectos'])];
        else
            return ['status' => 201, 'body' => json_encode(['codCliente' => $codCliente])];
    }


    public function patch($bd, $codCliente, $campos)
    {
        if (!$bd->getCliente($codCliente))
            return ['status' => 404, 'body' => json_encode(['message' => 'Cliente Not Found'])];

        $resultado = $bd->patchCliente($codCliente, $campos);
        if ($resultado < 0)
            return ['status' => 400, 'body' => json_encode(['message' => 'Datos incorrectos'])];

        $clienteActualizado = $bd->getCliente($codCliente);
        return ['status' => 200, 'body' => json_encode($clienteActualizado)];
    }

    public function delete($bd, $codCliente)
    {
        if ($bd->eliminarCliente($codCliente))
            return ['status' => 204];
        return ['status' => 404, 'body' => json_encode(['message' => 'Cliente Not Found'])];
    }

    public function deleteAll($bd)
    {
        if ($bd->eliminarTodosClientes())
            return ['status' => 204];
        return ['status' => 500, 'body' => json_encode(['message' => 'Error al eliminar clientes'])];
    }
}
