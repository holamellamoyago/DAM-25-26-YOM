package STAX;

import java.util.ArrayList;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLOutputFactory;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;
import javax.xml.stream.XMLStreamWriter;

import Clases.*;

public class GestorCorredoresSTAX {

    private String rutaArchivo;
    private TipoValidacion tipoValidacion;

    private XMLStreamReader reader;
    private XMLStreamWriter writter;

    public GestorCorredoresSTAX(String rutaArchivo, TipoValidacion tipoValidacion) {
        this.rutaArchivo = rutaArchivo;
        this.tipoValidacion = tipoValidacion;
    }

    public ArrayList<Corredor> leerCorredores() {
        if (reader == null) {
            reader = ConfiguracionSTAX.crearStreamReader(rutaArchivo, tipoValidacion);
        }

        return CorredoresSTAX.leerCorrredores(reader);
    }

    public void escribirCorredores(ArrayList<Corredor> corredores) {
        XMLOutputFactory outputFactory;
        if (writter == null) {
            outputFactory = XMLOutputFactory.newInstance();
            writter = ConfiguracionSTAX.crearStreamWritter(outputFactory, rutaArchivo);
        }

        try {
            XMLSTAXUtils.addStartDocument(writter);
            XMLSTAXUtils.addStartElemento(writter, "corredores"); // Corredores

            for (Corredor corredor : corredores) {
                if (corredor instanceof Velocista) {
                    Velocista velocista = (Velocista) corredor;
                    escribirCorredor(corredor);

                    XMLSTAXUtils.addStartElemento(writter, "velocidad_media");
                    XMLSTAXUtils.addTextoElemento(writter, String.valueOf(velocista.getVelocidadMedia()));
                    XMLSTAXUtils.addEndElement(writter); // Velocidad_media

                } else if (corredor instanceof Fondista) {
                    Fondista fondista = (Fondista) corredor;
                    escribirCorredor(corredor);

                    XMLSTAXUtils.addStartElemento(writter, "distancia_max");
                    XMLSTAXUtils.addTextoElemento(writter, String.valueOf(fondista.getDistanciaMax()));
                    XMLSTAXUtils.addEndElement(writter);

                }

                XMLSTAXUtils.addEndElement(writter); // velocista / fondista
            }

            XMLSTAXUtils.addEndElement(writter); // ← Cerrar <corredores>
            XMLSTAXUtils.addEndDocument(writter); // Cerrar documento
            writter.close(); // ← Cerrar el writer
        } catch (XMLStreamException e) {
            e.printStackTrace();
        }
    }

    private void escribirCorredor(Corredor c) {
        XMLSTAXUtils.addStartElemento(writter, c.getClass().getSimpleName().toLowerCase()); // velocista / fondista
        XMLSTAXUtils.addAtributo(writter, "codigo", c.getCodigo());
        XMLSTAXUtils.addAtributo(writter, "equipo", c.getEquipo());
        XMLSTAXUtils.addAtributo(writter, "dorsal", String.valueOf(c.getDorsal()));

        XMLSTAXUtils.addStartElemento(writter, "nombre");
        XMLSTAXUtils.addTextoElemento(writter, c.getNombre());
        XMLSTAXUtils.addEndElement(writter);

        XMLSTAXUtils.addStartElemento(writter, "fecha_nacimiento");
        XMLSTAXUtils.addTextoElemento(writter, String.valueOf(c.getFechaNacimiento()));
        XMLSTAXUtils.addEndElement(writter);

    }

    // Métodos auxiliares para escribir cada tipo
    // private void escribirVelocista(Velocista v) throws XMLStreamException {
    //     writter.writeStartElement("velocista");
    //     writter.writeAttribute("codigo", v.getCodigo());
    //     writter.writeAttribute("dorsal", String.valueOf(v.getDorsal()));
    //     writter.writeAttribute("equipo", v.getEquipo());

    //     writter.writeStartElement("nombre");
    //     writter.writeCharacters(v.getNombre());
    //     writter.writeEndElement();

    //     // Agrega más elementos: fecha_nacimiento, velocidad_media, historial, etc.
    //     writter.writeEndElement();
    // }

    // private void escribirFondista(Fondista f) throws XMLStreamException {
    //     // Similar a escribirVelocista, pero con distancia_max
    // }

}
