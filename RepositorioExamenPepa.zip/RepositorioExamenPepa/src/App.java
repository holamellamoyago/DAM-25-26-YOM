import Clases.TipoValidacion;
import STAX.GestorCorredoresSTAX;

public class App {
    public static void main(String[] args) throws Exception {
        GestorCorredoresSTAX gestorSTAX = new GestorCorredoresSTAX("Archivos/Corredores.xml",
                TipoValidacion.NO_VALIDAR);
        
        gestorSTAX.escribirCorredores(gestorSTAX.leerCorredores());
    }
}
