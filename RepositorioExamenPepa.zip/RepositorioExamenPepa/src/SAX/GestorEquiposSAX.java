package SAX;

import java.time.LocalDate;
import java.util.ArrayList;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

import Clases.Equipo;
import Clases.Patrocinador;
import Clases.TipoValidacion;

public class GestorEquiposSAX {

    private String rutaArchivo;
    private TipoValidacion tipoValidacion;

    public GestorEquiposSAX(String rutaArchivo, TipoValidacion tipoValidacion) {
        this.rutaArchivo = rutaArchivo;
        this.tipoValidacion = tipoValidacion;
    }

    public ArrayList<Equipo> getEquipos() {
        try {
            EquiposHandler handler = new EquiposHandler();
            XMLSAXUtils xmlsaxUtils = new XMLSAXUtils(rutaArchivo, tipoValidacion, handler);
            xmlsaxUtils.cargarDocumentoSAX().getXMLReader();

            return handler.getEquipos();
        } catch (SAXException e) {
            throw new ArithmeticException(e.toString());
        }



    }
}
