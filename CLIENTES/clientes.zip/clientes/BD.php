<?php
// BD.php
require_once 'validar.php';

class BD extends PDO
{
    private const SERVIDOR_BD = 'localhost';
    private const USUARIO_BD = 'root';
    private const PASSWORD_BD = '';
    private const BD = 'clientes';
    private const DSN = 'mysql:host=' . self::SERVIDOR_BD . ';dbname=' . self::BD . ';charset=utf8mb4';

    public function __construct() {
        parent::__construct(self::DSN, self::USUARIO_BD, self::PASSWORD_BD);
    }

    function getClientes($codCliente = ''): array {
        if ($codCliente == '')
            $WHERE = '';
        else if (!Validar::esEntero($codCliente))
            return [];
        else
            $WHERE = "WHERE codCliente=$codCliente";
            $sql = "SELECT codCliente,clientes.nombre AS nombre,apellidos,
                    NIF,clientes.codProvincia AS codProvincia,provincias.nombre AS nombreProvincia
                    FROM clientes LEFT JOIN provincias ON clientes.codProvincia=provincias.codProvincia
                    $WHERE ORDER BY apellidos, clientes.nombre";

        if ($cursor = $this->query($sql))
            return $cursor->fetchAll(PDO::FETCH_OBJ);

        return [];
    }

    function getCliente($codCliente): object|null {
        $clientes = $this->getClientes($codCliente);
        if (empty($clientes)) return null;
        return $clientes[0];
    }

    function touchCliente($nombre, $apellidos, $NIF, $codProvincia, $codCliente = ''): int {
        $nombre = strip_tags($nombre);
        $apellidos = strip_tags($apellidos);

        if (!Validar::esNIFvalido($NIF)) return -1;
        if (!Validar::esEntero($codProvincia, true)) return -1;
        if ($codProvincia == '') $codProvincia = null;

        if ($esEdicion = ($codCliente != '')) {
            if (!Validar::esEntero($codCliente)) return -1;
            $sql = "UPDATE clientes SET nombre=:nombre,
                    apellidos=:apellidos,NIF=:NIF,codProvincia=:codProvincia WHERE codCliente=:codCliente";
        } else $sql = "INSERT INTO Clientes (nombre, apellidos, NIF, codProvincia) VALUES
                        (:nombre,:apellidos,:NIF,:codProvincia)";

        $stmt = $this->prepare($sql);
        $stmt->bindParam(":nombre", $nombre);
        $stmt->bindParam(":apellidos", $apellidos);
        $stmt->bindParam(":NIF", $NIF);
        $stmt->bindParam(":codProvincia", $codProvincia);

        if ($esEdicion) $stmt->bindParam(":codCliente", $codCliente);

        try {
            $stmt->execute();
            if (!$esEdicion) $codCliente = $this->lastInsertId();
        } catch (PDOException $ex) {
            return -1;
        }

        return $codCliente;
    }


    function patchCliente($codCliente, $campos): int {
        if (!Validar::esEntero($codCliente)) return -1;

        $camposPermitidos = ['nombre', 'apellidos', 'NIF', 'codProvincia'];
        $sets = [];
        $valores = [];

        foreach ($campos as $campo => $valor) {
            if (!in_array($campo, $camposPermitidos)) continue;

            if ($campo === 'NIF' && !Validar::esNIFvalido($valor)) return -1;
            if ($campo === 'codProvincia' && !Validar::esEntero($valor, true)) return -1;
            if ($campo === 'nombre' || $campo === 'apellidos') $valor = strip_tags($valor);
            if ($campo === 'codProvincia' && $valor === '') $valor = null;

            $sets[] = "$campo=:$campo";
            $valores[$campo] = $valor;
        }

        if (empty($sets)) return -1;

        $sql = "UPDATE clientes SET " . implode(',', $sets) . " WHERE codCliente=:codCliente";
        $stmt = $this->prepare($sql);
        foreach ($valores as $campo => $valor)
            $stmt->bindValue(":$campo", $valor);
        $stmt->bindValue(":codCliente", $codCliente);

        try {
            $stmt->execute();
            if ($stmt->rowCount() === 0) return 0;
        } catch (PDOException $ex) {
            return -1;
        }

        return (int)$codCliente;
    }

    function eliminarCliente($codCliente): bool {
        if (!Validar::esEntero($codCliente)) return false;
        $sql = "DELETE FROM clientes WHERE codCliente=$codCliente";
        if (!$this->query($sql)) return false;
        return true;
    }

    function eliminarTodosClientes(): bool {
        $sql = "DELETE FROM clientes";
        if (!$this->query($sql)) return false;
        return true;
    }


    function getProvincias(): array {
        $sql = 'SELECT * FROM provincias ORDER BY nombre';
        return $this->query($sql)->fetchAll(PDO::FETCH_OBJ);
    }
}

    try {
        $bd = new BD();
    } catch (PDOException $ex) {
        exit('No se ha podido conectar con la BD');
    }
