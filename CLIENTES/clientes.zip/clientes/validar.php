<?php

class Validar
{
    static function esEntero($num, $permitirVacio = false): bool
    {
        if ($permitirVacio) if ($num == '') return true;
        return preg_match('/^\d+$/', $num);
    }

    static function esNIFvalido($nif): bool
    {
        //TODO no incluye NIFs válidos que empiecen por letra
        $letras = 'TRWAGMYFPDXBNJZSQVHLCKE';
        $erNIF = "/^(\d{8})([$letras])$/i";
        if (!preg_match($erNIF, $nif, $grupos)) return false;
        $dni = $grupos[1];
        $letraNIF = $grupos[2];
        return ($letras[($dni % 23)] == strtoupper($nif[8]));
    }
}
// 