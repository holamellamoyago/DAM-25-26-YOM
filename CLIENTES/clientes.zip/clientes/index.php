<?php
// index.php
require 'Router.php';
require 'controladores/ClienteControlador.php';
require 'BD.php';

header('Content-Type: application/json');
$router = new Router();
$controlador = new ClienteControlador();

$router->get('/clientes', function () use ($controlador, $bd) {
    return $controlador->getAll($bd);
});

$router->get('/cliente/(\d+)', function ($params) use ($controlador, $bd) {
    $codCliente = $params[1];
    return $controlador->get($bd, $codCliente);
});

$router->delete('/clientes', function () use ($controlador, $bd) {
    return $controlador->deleteAll($bd);
});

$router->delete('/cliente/(\d+)', function ($params) use ($controlador, $bd) {
    $codCliente = $params[1];
    return $controlador->delete($bd, $codCliente);
});

$router->patch('/cliente/(\d+)', function ($params) use ($controlador, $bd) {
    $codCliente = $params[1];
    $body = file_get_contents('php://input');
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (str_contains($contentType, 'application/json'))
        $campos = json_decode($body, true);
    else {
        parse_str($body, $campos);
    }
    return $controlador->patch($bd, $codCliente, $campos);
});

$router->post('/clientes', function () use ($controlador, $bd) {
    $body = file_get_contents('php://input');
    $contentType = $_SERVER['CONTENT_TYPE'] ?? '';
    if (str_contains($contentType, 'application/json'))
        $cliente = json_decode($body, false);
    else {
        parse_str($body, $datos);
        $cliente = (object)$datos;
    }
    return $controlador->post($bd, $cliente);
});

$router->dispatch($_SERVER['REQUEST_METHOD'], $_SERVER['PATH_INFO'] ?? '/');
