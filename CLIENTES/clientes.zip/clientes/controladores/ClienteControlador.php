<?php

class ClienteControlador
{
    public function getAll($bd) {
        return ['body' => json_encode($bd->getClientes())];
    }
    
    public function get($bd, $codCliente) {
        if ($cliente = $bd->getCliente($codCliente))
            return ['body' => json_encode($cliente)];
        return ['status' => 404, 'body' => json_encode(['message' => 'Cliente Not Found'])];
    }

    public function post($bd, $c) {
        $codCliente = $bd->touchCliente($c->nombre ?? '', $c->apellidos ?? '', $c->NIF ?? '', $c->codProvincia ?? '');
        if ($codCliente < 0)
            return ['status' => 422, 'body' => json_encode(['message' => 'Datos incorrectos'])];
        else
            return ['status' => 201, 'body' => json_encode(['codCliente' => $codCliente])];
    }

    public function patch($bd, $codCliente, $campos) {
        if (!$bd->getCliente($codCliente))
            return ['status' => 404, 'body' => json_encode(['message' => 'Cliente Not Found'])];

        $resultado = $bd->patchCliente($codCliente, $campos);
        if ($resultado < 0)
            return ['status' => 400, 'body' => json_encode(['message' => 'Datos incorrectos'])];

        $clienteActualizado = $bd->getCliente($codCliente);
        return ['status' => 200, 'body' => json_encode($clienteActualizado)];
    }

    public function delete($bd, $codCliente) {
        if ($bd->eliminarCliente($codCliente))
            return ['status' => 204];
        return ['status' => 404, 'body' => json_encode(['message' => 'Cliente Not Found'])];
    }

    public function deleteAll($bd) {
        if ($bd->eliminarTodosClientes())
            return ['status' => 204];
        return ['status' => 500, 'body' => json_encode(['message' => 'Error al eliminar clientes'])];
    }
}
