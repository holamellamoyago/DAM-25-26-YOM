package Persistencia.JAXB;
// YAGO OTERO MARTINEZ 39511342X

import java.io.File;
import java.util.ArrayList;

import Clases.Alojamienmtos;
import Clases.Estancia;
import Clases.Reserva;
import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;

public class XMLJAXBUtils {
    public static <T> T unmarshall(Class<T> clase, String rutaArchivo) {
        try {
            JAXBContext context = JAXBContext.newInstance(clase);

            Unmarshaller unmarshaller = context.createUnmarshaller();

            return clase.cast(unmarshaller.unmarshal(new File(rutaArchivo)));
        } catch (JAXBException e) {
            System.out.println("JAXB EXCEPTION " + e);
            Throwable linked = e.getLinkedException();
            if (linked != null) {
                System.out.println("LINKED EXCEPTION: " + linked.getMessage());
                linked.printStackTrace();
            }

            return null;
        }

    }

    public static Alojamienmtos clasificarAlojamientos(Alojamienmtos alojamienmtos) {

        for (int i = 0; i < alojamienmtos.getAlojamientos().size(); i++) {
            Estancia estancia = alojamienmtos.getAlojamientos().get(i);

            if (estancia.getReservas().isEmpty()) {
                alojamienmtos.getAlojamientos().remove(i);
            }

            if (!estancia.getReservas().isEmpty()) {
                Reserva ultReserva = estancia.getReservas().getLast();

                estancia.setReservas(new ArrayList<>());
                // estancia.getReservas().add(ultReserva);

                // if (estancia.getReservas().isEmpty()) {
                // alojamienmtos.getAlojamientos().remove(estancia);
                // }

                if (ultReserva.getFechaFin() == null) {
                    estancia.getReservas().add(ultReserva);
                }

            }
        }

        return alojamienmtos;
    }
}
