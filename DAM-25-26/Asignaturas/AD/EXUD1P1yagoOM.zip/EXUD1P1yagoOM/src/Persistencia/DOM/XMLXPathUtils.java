package Persistencia.DOM;
// YAGO OTERO MARTINEZ 39511342X

import javax.xml.xpath.*;
import org.w3c.dom.*;
import ManejadorErrorres.*;

public class XMLXPathUtils {

    public static NodeList cogerAlojamientos(Document document, String expresion) {
        try {
            XPath xPath = XPathFactory.newInstance().newXPath();
            XPathExpression expresionXPath = xPath.compile(expresion);

            NodeList nodos = (NodeList) expresionXPath.evaluate(document, XPathConstants.NODESET);

            return nodos;
        } catch (XPathExpressionException e) {
            throw new ExcepcionXML("Error al compilar el XPath");
        }
    }

    public static boolean comprobarExistenciaAlojamiento(Document document, String numeroAlojamiento) {
        // Tuve que comprobar por separado porqué no me iba la expresion completa

        String expresion = "//Habitacion[@numero=\"" + numeroAlojamiento + "\"]";
        NodeList nodos = XMLXPathUtils.cogerAlojamientos(document, expresion);

        if (nodos.getLength() > 0) {
            System.out.println("Habitción encontrada");
            return true;
        }

        expresion = "//Suite[@numero=\"" + numeroAlojamiento + "\"]";
        nodos = XMLXPathUtils.cogerAlojamientos(document, expresion);

        if (nodos.getLength() > 0) {
            System.out.println("Suite encontrada");
            return true;
        }

        return false;

    }

    public static boolean comprobarExistenciaReserva(Document document, String codigoReserva) {

        String expresion = "//Reserva[@codigo=\"" + codigoReserva + "\"]";
        NodeList nodos = XMLXPathUtils.cogerAlojamientos(document, expresion);

        if (nodos.getLength() > 0) {
            System.out.println("Reserva encontrada");
            return true;
        }

        return false;

    }

    // Reporta true si esta ocupaada
    public static boolean comprobarAlojamientoOcupado(Document document, String numeroAlojamiento) {
        // Tuve que comprobar por separado porqué no me iba la expresion completa

        String expresion = "//Habitacion[@numero=\"" + numeroAlojamiento + "\"]";
        NodeList nodos = XMLXPathUtils.cogerAlojamientos(document, expresion);

        if (nodos.getLength() > 0) {
            Element tipoAlojamiento = (Element) nodos.item(0);
            return comprobarUltimaReserva(tipoAlojamiento);

        }

        expresion = "//Suite[@numero=\"" + numeroAlojamiento + "\"]";
        nodos = XMLXPathUtils.cogerAlojamientos(document, expresion);

        if (nodos.getLength() > 0) {
            Element tipoAlojamiento = (Element) nodos.item(0);
            return comprobarUltimaReserva(tipoAlojamiento);
        }

        return false;

    }

    // Devuelve true si esta ocupada
    private static boolean comprobarUltimaReserva(Element tipoAlojamiento) {
        NodeList reservas = tipoAlojamiento.getElementsByTagName("Reserva");

        if (reservas.getLength() <= 0) {
            return false;
        }

        Element ultimaReserva = (Element) reservas.item(reservas.getLength() - 1);

        Element elementFechaFin = (Element) ultimaReserva.getElementsByTagName("FechaFin").item(0);

        if (elementFechaFin == null) {
            return true;
        }

        return false;
    }

    // TODO: Posible optimización 
    public static Element getElementoTipoAlojamiento(Document document,String numeroAlojamiento) {
        String expresion = "//Habitacion[@numero=\"" + numeroAlojamiento + "\"]";
        NodeList nodos = XMLXPathUtils.cogerAlojamientos(document, expresion);

        if (nodos.getLength() > 0) {
            Element tipoAlojamiento = (Element) nodos.item(0);
            return tipoAlojamiento;
        }

        expresion = "//Suite[@numero=\"" + numeroAlojamiento + "\"]";
        nodos = XMLXPathUtils.cogerAlojamientos(document, expresion);

        if (nodos.getLength() > 0) {
            Element tipoAlojamiento = (Element) nodos.item(0);
            return tipoAlojamiento;
        }

        return null;
    }

    // Devuelve true si existe el elemento <reservas>
    public static boolean existenReservas(Element tipoHabitacion) {
        NodeList reservas = tipoHabitacion.getElementsByTagName("Reservas");

        if (reservas.getLength() > 0) {
            System.out.println("Existen reservas");
            return true;
        }

        return false;
    }
}
