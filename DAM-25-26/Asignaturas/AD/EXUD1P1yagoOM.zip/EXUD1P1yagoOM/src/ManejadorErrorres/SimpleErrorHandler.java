package ManejadorErrorres;
// YAGO OTERO MARTINEZ 39511342X

import org.xml.sax.ErrorHandler;
import org.xml.sax.SAXException;
import org.xml.sax.SAXParseException;

public class SimpleErrorHandler implements ErrorHandler {


    @Override
    public void warning(SAXParseException exception) throws SAXException {
        System.out.println("Warning: " + exception.toString());
    }

    @Override
    public void error(SAXParseException exception) throws SAXException {
        System.out.println("Warning: " + exception.toString());

    }

    @Override
    public void fatalError(SAXParseException exception) throws SAXException {
        System.out.println("Warning: " + exception.toString());

    }

}
