package ManejadorErrorres;
// YAGO OTERO MARTINEZ 39511342X

public class ExcepcionXML extends RuntimeException{

    public ExcepcionXML(String mensaje, Throwable causa ) {
        super(mensaje, causa);
    }

    public ExcepcionXML(String mensaje) {
        super(mensaje);
    }

    
}
