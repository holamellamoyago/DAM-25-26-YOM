import Logica.*;
// YAGO OTERO MARTINEZ 39511342X
import java.time.LocalDate;

import Clases.*;

public class App {
    public static void main(String[] args) throws Exception {
        GestorAlojamientosJAXB gestorAlojamientosJAXB = new GestorAlojamientosJAXB("AlojamientosHotelCOPIA.xml");
        System.out.println(gestorAlojamientosJAXB.getAlojamientosActivos());

        // Reserva para testear el DOM
        Usuario usuario = new Usuario();
        usuario.setDni("12345678A");
        usuario.setNombre("Yago");

        Reserva reserva = new Reserva();
        reserva.setCodigo("Y1");
        reserva.setFechaInicio(LocalDate.parse("2025-10-10"));
        reserva.setUsuario(usuario);

        System.out.println();

        GestorAlojamientosDOM gestorDOM = new GestorAlojamientosDOM("AlojamientosHotel.xml", TipoValidacion.DTD);
        gestorDOM.registrarNuevaReserva(reserva, "S202");
        // gestorDOM.registrarNuevaReserva(reserva, "H108");

    }
}
