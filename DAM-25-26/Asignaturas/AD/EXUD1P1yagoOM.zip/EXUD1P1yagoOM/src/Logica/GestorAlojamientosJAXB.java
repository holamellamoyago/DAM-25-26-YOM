package Logica;
// YAGO OTERO MARTINEZ 39511342X

import Clases.Alojamienmtos;
import Persistencia.JAXB.XMLJAXBUtils;

public class GestorAlojamientosJAXB {
    private String rutaArchivo;

    public GestorAlojamientosJAXB(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public Alojamienmtos getAlojamientosActivos() {
        Alojamienmtos alojamientos = XMLJAXBUtils.unmarshall(Alojamienmtos.class, rutaArchivo);
        return XMLJAXBUtils.clasificarAlojamientos(alojamientos);

    }

}
