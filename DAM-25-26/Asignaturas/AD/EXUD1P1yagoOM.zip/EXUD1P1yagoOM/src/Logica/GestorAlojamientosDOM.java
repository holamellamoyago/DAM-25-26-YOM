package Logica;
// YAGO OTERO MARTINEZ 39511342X

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import Clases.*;
import ManejadorErrorres.*;
import Persistencia.DOM.*;

public class GestorAlojamientosDOM {
    private String rutaArchivo;
    private TipoValidacion tipoValidacion;

    public GestorAlojamientosDOM(String rutaArchivo, TipoValidacion tipoValidacion) {
        this.rutaArchivo = rutaArchivo;
        this.tipoValidacion = tipoValidacion;
    }

    public void registrarNuevaReserva(Reserva reserva, String numeroAlojamiento) {
        Document document = XMLDOMUtils.cargarDocumentoXML(rutaArchivo, tipoValidacion);

        validarReserva(reserva, numeroAlojamiento, document);

        // Me coloco en el elemento de la habitacion o suite
        Element tipoHabitacion = XMLXPathUtils.getElementoTipoAlojamiento(document, numeroAlojamiento);

        /*
         * Lo que hago aqui es comprobar si existe el elemento reservas por que en el
         * propio xml
         * si hay alguna habitacion sin ellas cuando voy a color cada reserva induvidual
         * se colocaria en el elemento suite o habitacion que en realidad para estar
         * bien
         * tiene que ir dentro de reservas
         */

        Element elementoReservas;
        if (XMLXPathUtils.existenReservas(tipoHabitacion)) {
            elementoReservas = (Element) tipoHabitacion.getElementsByTagName("Reservas").item(0);
        } else {
            elementoReservas = XMLDOMUtils.addElement(document, "Reservas", tipoHabitacion);
        }

        // cojo se elemento para añadirle los atributos
        Element elementoReserva = XMLDOMUtils.addElement(document, "Reserva", elementoReservas);
        XMLDOMUtils.addAtributo(document, "codigo", reserva.getCodigo(), elementoReserva);

        // Añado el usuario a al reserva
        Element elementUsuario = XMLDOMUtils.addElement(document, "Usuario", reserva.getUsuario().getNombre(),
                elementoReserva);
        XMLDOMUtils.addAtributo(document, "dni", reserva.getUsuario().getDni(), elementUsuario);

        // añado la fecha de inicio
        XMLDOMUtils.addElement(document, "FechaInicio", String.valueOf(reserva.getFechaInicio()), elementoReserva);

        // Cambio el atributo del alojamiento
        XMLDOMUtils.modificarAtributo(tipoHabitacion, "estado", "ocupada");

        final String RUTA_FINAL = "AlojamientosUpdate.xml";
        XMLDOMUtils.guardarDocumentoXML(document, RUTA_FINAL);
        System.out.println("Documento guardado");

    }

    private void validarReserva(Reserva reserva, String numeroAlojamiento, Document document) {
        Usuario usuario = reserva.getUsuario();

        if (usuario.getDni() == null || usuario.getDni().isEmpty()) {
            throw new ExcepcionXML("El usuario debe de tener DNI");
        }

        if (usuario.getNombre() == null || usuario.getNombre().isEmpty()) {
            throw new ExcepcionXML("El usuario debe de tener NOMBRE");
        }

        if (numeroAlojamiento == null || numeroAlojamiento.isEmpty()) {
            throw new ExcepcionXML("El numero de alojamiento es inválido");
        }

        if (reserva.getCodigo() == null || reserva.getCodigo().isEmpty()) {
            throw new ExcepcionXML("El numero de reserva es inválido");
        }

        if (reserva.getFechaInicio() == null) {
            throw new ExcepcionXML("No hay fecha de inicio");
        }

        // Compruebo existencia alojamiento
        boolean existe = XMLXPathUtils.comprobarExistenciaAlojamiento(document, numeroAlojamiento);
        if (!existe) {
            throw new ExcepcionXML("No existe ningun alojamiento con ese numero");
        }

        // Compruebo que no exista una reserva ya con ese código
        existe = XMLXPathUtils.comprobarExistenciaReserva(document, reserva.getCodigo());
        if (existe) {
            throw new ExcepcionXML("Ya existe una reserva con ese codigo");
        }

        // Compruebp que ese alojamiento no este ya ocupado
        existe = XMLXPathUtils.comprobarAlojamientoOcupado(document, numeroAlojamiento);
        if (existe) {
            throw new ExcepcionXML("Este alojamiento esta aun ocupado , no se puede reservar");
        }
    }

}
