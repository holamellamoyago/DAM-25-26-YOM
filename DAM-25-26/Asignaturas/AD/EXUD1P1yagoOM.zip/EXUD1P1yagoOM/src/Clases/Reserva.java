package Clases;
// YAGO OTERO MARTINEZ 39511342X

import java.time.LocalDate;

import Adapter.LocalDateAdapter;
import jakarta.xml.bind.annotation.*;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlAccessorType(XmlAccessType.FIELD)
public class Reserva {
    @XmlAttribute(name = "codigo", required = true)
    private String codigo;

    @XmlElement(name = "Usuario")
    private Usuario usuario;

    @XmlElement(name = "FechaInicio")
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate fechaInicio;

    @XmlElement(name = "FechaFin", required = false)
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate fechaFin;

    public Reserva() {
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public LocalDate getFechaInicio() {
        return fechaInicio;
    }

    public void setFechaInicio(LocalDate fechaInicio) {
        this.fechaInicio = fechaInicio;
    }

    public LocalDate getFechaFin() {
        return fechaFin;
    }

    public void setFechaFin(LocalDate fechaFin) {
        this.fechaFin = fechaFin;
    }

    @Override
    public String toString() {
        return "\nReserva: " + codigo + ", " + fechaInicio + ", Usuario: " + getUsuario();
    }

}
