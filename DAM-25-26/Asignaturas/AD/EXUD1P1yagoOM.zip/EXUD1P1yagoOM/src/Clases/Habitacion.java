package Clases;
// YAGO OTERO MARTINEZ 39511342X

import jakarta.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class Habitacion extends Estancia {
    
    @XmlAttribute(name = "tipo" , required = true)
    private TipoHabitacion tipoHabitacion;

    public Habitacion() {
    }

    public TipoHabitacion getTipoHabitacion() {
        return tipoHabitacion;
    }

    public void setTipoHabitacion(TipoHabitacion tipoHabitacion) {
        this.tipoHabitacion = tipoHabitacion;
    }

    @Override
    public String toString() {
        String s1 =  "\nHabitacion (" + tipoHabitacion + "):" + getNumero() + getReservas();



        return s1;
    }

    
    
    

}
