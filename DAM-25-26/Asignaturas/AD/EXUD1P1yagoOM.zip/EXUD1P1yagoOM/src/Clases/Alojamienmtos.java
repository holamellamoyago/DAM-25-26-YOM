package Clases;

import java.util.ArrayList;
// YAGO OTERO MARTINEZ 39511342X

import jakarta.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Alojamientos")
public class Alojamienmtos {
    
    @XmlElements({
        @XmlElement(name = "Habitacion", type = Habitacion.class),
        @XmlElement(name = "Suite", type = Suite.class)
    })

    private ArrayList<Estancia> alojamientos;

    public Alojamienmtos() {
        alojamientos = new ArrayList<>();
    }

    @Override
    public String toString() {
        return alojamientos.toString();
    }

    public ArrayList<Estancia> getAlojamientos() {
        return alojamientos;
    }

    public void setAlojamientos(ArrayList<Estancia> alojamientos) {
        this.alojamientos = alojamientos;
    }

    

    

    
}
