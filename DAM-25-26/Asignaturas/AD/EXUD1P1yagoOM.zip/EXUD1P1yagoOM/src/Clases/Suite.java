package Clases;
// YAGO OTERO MARTINEZ 39511342X

import jakarta.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class Suite extends Estancia {
    @XmlAttribute(name = "terraza", required = true)
    private TipoTerraza tipoTerraza;

    @XmlAttribute(name = "categoria", required = true)
    private TipoCategoria tipoCategoria;

    public Suite() {
    }

    public TipoTerraza getTipoTerraza() {
        return tipoTerraza;
    }

    public void setTipoTerraza(TipoTerraza tipoTerraza) {
        this.tipoTerraza = tipoTerraza;
    }

    public TipoCategoria getTipoCategoria() {
        return tipoCategoria;
    }

    public void setTipoCategoria(TipoCategoria tipoCategoria) {
        this.tipoCategoria = tipoCategoria;
    };

    @Override
    public String toString() {
        String s1 = "\nSuite (" + tipoCategoria + "):" + getNumero() + getReservas();

        return s1;
    }

}
