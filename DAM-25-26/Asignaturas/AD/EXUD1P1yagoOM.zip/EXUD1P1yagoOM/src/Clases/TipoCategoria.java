package Clases;
// YAGO OTERO MARTINEZ 39511342X

public enum TipoCategoria {
    Junior,
    Presidencial,
    Familiar
}
