package Clases;
// YAGO OTERO MARTINEZ 39511342X

public enum TipoValidacion {
    NO_VALIDAR,
    DTD,
    XSD
}

