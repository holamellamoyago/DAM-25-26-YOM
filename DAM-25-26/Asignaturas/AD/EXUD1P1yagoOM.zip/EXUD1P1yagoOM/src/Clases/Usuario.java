package Clases;
// YAGO OTERO MARTINEZ 39511342X

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
public class Usuario {
    @XmlValue
    private String nombre;

    @XmlAttribute(name = "dni", required = true)
    private String dni;

    public Usuario() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        String s1 = nombre  + "(" + getDni() + ")";

        return s1;
    }

}
