package Clases;
// YAGO OTERO MARTINEZ 39511342X

import java.util.ArrayList;

import jakarta.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlSeeAlso({
        Habitacion.class,
        Suite.class
})
public abstract class Estancia {
    @XmlAttribute(name = "numero", required = true)
    private String numero;

    @XmlAttribute(name = "estado", required = true)
    private boolean ocupada;

    @XmlAttribute(name = "precio", required = true)
    private float precio;

    @XmlElementWrapper(name = "Reservas")
    @XmlElement(name = "Reserva")
    private ArrayList<Reserva> reservas;

    public Estancia() {
        reservas = new ArrayList<>();
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public boolean isOcupada() {
        return ocupada;
    }

    public void setOcupada(boolean ocupada) {
        this.ocupada = ocupada;
    }

    public float getPrecio() {
        return precio;
    }

    public void setPrecio(float precio) {
        this.precio = precio;
    }

    public ArrayList<Reserva> getReservas() {
        return reservas;
    }

    public void setReservas(ArrayList<Reserva> reservas) {
        this.reservas = reservas;
    }
}
