package AD.Tema1.Actividad6.Clases;

import jakarta.xml.bind.annotation.*;
import jakarta.xml.bind.annotation.XmlValue;

@XmlAccessorType(XmlAccessType.FIELD)
public class Puntuacion implements Comparable<Puntuacion> {
    // private static final long serialVersionUID = 1L;

    @XmlAttribute(name = "anio", required = true)
    private int anio;

    @XmlValue
    private float puntos;

    public Puntuacion() {
    }

    public Puntuacion(int anio, float puntos) {
        this.anio = anio;
        this.puntos = puntos;
    }

    public int getAnio() {
        return anio;
    }

    public void setAnio(int anio) {
        this.anio = anio;
    }

    public float getPuntos() {
        return puntos;
    }

    public void setPuntos(float puntos) {
        this.puntos = puntos;
    }

    @Override
    public int compareTo(Puntuacion o) {
        return this.anio - o.anio;
    }

    @Override
    public String toString() {
        return "Puntuacion " + anio + ", puntos=" + puntos + "]";
    }

}
