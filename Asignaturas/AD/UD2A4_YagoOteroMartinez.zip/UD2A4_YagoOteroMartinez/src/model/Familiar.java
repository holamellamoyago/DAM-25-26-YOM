package model;

import java.sql.Date;

public class Familiar {

    private String nssEmpregado;
    private int numInterno;
    private String nssFamiliar;
    private String nome;
    private String apelidos;
    private Date dataNacemento;
    private String parentesco;
    private char sexo;

    // CORRECCION: constructor de dominio, numInterno se calcula en la lógica
    public Familiar(String nssEmpregado,
                    String nssFamiliar,
                    String nome,
                    String apelidos,
                    Date dataNacemento,
                    String parentesco,
                    char sexo) {

        this.nssEmpregado = nssEmpregado;
        this.nssFamiliar = nssFamiliar;
        this.nome = nome;
        this.apelidos = apelidos;
        this.dataNacemento = dataNacemento;
        this.parentesco = parentesco;
        this.sexo = sexo;
    }


    public Familiar(String nssEmpregado, int numInterno, String nssFamiliar,
                    String nome, String apelidos, Date dataNacemento,
                    String parentesco, char sexo) {
        this.nssEmpregado = nssEmpregado;
        this.numInterno = numInterno;
        this.nssFamiliar = nssFamiliar;
        this.nome = nome;
        this.apelidos = apelidos;
        this.dataNacemento = dataNacemento;
        this.parentesco = parentesco;
        this.sexo = sexo;
    }

    public String getNssEmpregado() {
        return nssEmpregado;
    }

    public void setNssEmpregado(String nssEmpregado) {
        this.nssEmpregado = nssEmpregado;
    }

    public int getNumInterno() {
        return numInterno;
    }

    public void setNumInterno(int numInterno) {
        this.numInterno = numInterno;
    }

    public String getNssFamiliar() {
        return nssFamiliar;
    }

    public void setNssFamiliar(String nssFamiliar) {
        this.nssFamiliar = nssFamiliar;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getApelidos() {
        return apelidos;
    }

    public void setApelidos(String apelidos) {
        this.apelidos = apelidos;
    }

    public Date getDataNacemento() {
        return dataNacemento;
    }

    public void setDataNacemento(Date dataNacemento) {
        this.dataNacemento = dataNacemento;
    }

    public String getParentesco() {
        return parentesco;
    }

    public void setParentesco(String parentesco) {
        this.parentesco = parentesco;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    @Override
    public String toString() {
        return "Familiar{" +
                "nssEmpregado='" + nssEmpregado + '\'' +
                ", numInterno=" + numInterno +
                ", nssFamiliar='" + nssFamiliar + '\'' +
                ", nome='" + nome + '\'' +
                ", apelidos='" + apelidos + '\'' +
                ", dataNacemento=" + dataNacemento +
                ", parentesco='" + parentesco + '\'' +
                ", sexo=" + sexo +
                '}';
    }
}
