package clases;

import java.util.ArrayList;

public class Fotografo {
    private boolean borrado;
    private int codigo;
    private String numLicencia;
    private String nombre;
    private String estudio;
    private int numFotografia;
    private ArrayList<Fotografia> fotografias;

    public Fotografo(boolean borrado, int codigo, String numLicencia, String nombre, String estudio, int numFotografia,
            ArrayList<Fotografia> fotografias) {
        this.borrado = borrado;
        this.codigo = codigo;
        this.numLicencia = numLicencia;
        this.nombre = nombre;
        this.estudio = estudio;
        this.numFotografia = numFotografia;
        this.fotografias = fotografias;
    }

    public Fotografo() {
    }

    public boolean isBorrado() {
        return borrado;
    }

    public void setBorrado(boolean borrado) {
        this.borrado = borrado;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    public String getNumLicencia() {
        return numLicencia;
    }

    public void setNumLicencia(String numLicencia) {
        this.numLicencia = numLicencia;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEstudio() {
        return estudio;
    }

    public void setEstudio(String estudio) {
        this.estudio = estudio;
    }

    public int getNumFotografia() {
        return numFotografia;
    }

    public void setNumFotografia(int numFotografia) {
        this.numFotografia = numFotografia;
    }

    public ArrayList<Fotografia> getFotografias() {
        return fotografias;
    }

    public void setFotografias(ArrayList<Fotografia> fotografias) {
        this.fotografias = fotografias;
    }

    @Override
    public String toString() {
        String s0 = "\n-----------------------------------------------------------";
        String s1 = "\nCódigo: " + codigo + ", Licencia: " + numLicencia + ", Nombre: " + nombre + ", Estudio: "
                + estudio + ", Número de fotografías: " + numFotografia;
        String s2 = "\nFotografías: " + fotografias;

        return s0 + s1 + s2;

    }

    public String toStringResumido() {
        String s1 = "\nCódigo: " + codigo + ", Nombre: " + nombre + ", Licencia: " + numLicencia;

        return s1;
    }

}
