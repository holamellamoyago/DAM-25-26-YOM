package persistencia;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.xml.stream.XMLInputFactory;
import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

public class XMLSTAXUtils {

    /*
     * GUÍA MÉTODOS
     * 
     * + crearStreamReader
     * 
     * - leerNombreEtiqueta
     * - leerAtributo
     * - leerTexto
     * 
     */

    public static XMLStreamReader crearStreamReader(String rutaArchivo) {
        try {
            XMLInputFactory inputFactory = XMLInputFactory.newInstance();
            return inputFactory.createXMLStreamReader(new FileInputStream(new File(rutaArchivo)));
        } catch (FileNotFoundException | XMLStreamException e) {
            throw new ArithmeticException(e.toString());
        }
    }

    public static String leerNombreEtiqueta(XMLStreamReader reader) {
        if (reader.isStartElement() || reader.isEndElement()) {
            return reader.getLocalName();
        } else {
            return null;
        }
    }

    public static String leerAtributo(XMLStreamReader reader, String nombreAtributo) {
        return reader.getAttributeValue(null, nombreAtributo);
    }

    public static String leerTexto(XMLStreamReader reader) throws XMLStreamException {
        return reader.getEventType() == XMLStreamConstants.CHARACTERS ? reader.getText().trim()
                : reader.getElementText();
    }

}
