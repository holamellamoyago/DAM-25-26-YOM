package persistencia;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Random;

import clases.Fotografia;
import clases.Fotografo;
import excepciones.ArchivoNoExistente;

public class DatRandomUtils {
    final static int TAMANHO_REGISTRO = 1024;

    public static RandomAccessFile abrirArchivoRandom(File file) throws ArchivoNoExistente {
        try {
            return new RandomAccessFile(file, "rw");
        } catch (FileNotFoundException e) {
            throw new ArchivoNoExistente();

        }
    }

    public static ArrayList<Fotografo> leerFotografos(RandomAccessFile randomFile) {
        ArrayList<Fotografo> fotografos = new ArrayList<>();

        try {
            int i = 0;
            randomFile.seek(0);

            Fotografo fotografo;
            while ((fotografo = leerCamposFotografo(randomFile)) != null) {

                fotografos.add(fotografo);

                i++;
                randomFile.seek(i * TAMANHO_REGISTRO);
            }

            return fotografos;

        } catch (IOException e) {
            e.printStackTrace();
            return fotografos;
        }

    }

    private static Fotografo leerCamposFotografo(RandomAccessFile randomFile) {
        Fotografo fotografo = new Fotografo();

        try {
            fotografo.setBorrado(randomFile.readBoolean()); // borrado

            if (fotografo.isBorrado()) {
                return null;
            }

            fotografo.setCodigo(randomFile.readInt()); // codigo
            fotografo.setNumLicencia(randomFile.readUTF()); // numLicencia
            fotografo.setNombre(randomFile.readUTF()); // nombre
            fotografo.setEstudio(randomFile.readUTF()); // estudio
            fotografo.setNumFotografia(randomFile.readInt()); // Este es el total de fotos

            ArrayList<Fotografia> fotografias = new ArrayList<>();
            for (int i = 0; i < fotografo.getNumFotografia(); i++) {
                Fotografia fotografia = new Fotografia();
                fotografia.setTitulo(randomFile.readUTF()); // titulo

                long fechaLong = randomFile.readLong(); // fechaToma
                // System.out.println(fechaLong);
                // LocalDate fecha = LocalDate.parse(String.valueOf(fechaLong));
                // System.out.println(fecha);
                // fotografia.setFechaToma(fecha);

                fotografia.setTipo(randomFile.readUTF());
                fotografia.setTamanoMB(randomFile.readDouble());

                fotografias.add(fotografia);
            }

            fotografo.setFotografias(fotografias);

            return fotografo;
        } catch (IOException e) {
            return null;
        }

    }

    public static long cogerSiguientePosicion(RandomAccessFile rdmFile) throws IOException {
        boolean existe = rdmFile.length() > 0;

        if (!existe) {
            return 0;
        } else {
            return cogerUltimoRegistro(rdmFile) * TAMANHO_REGISTRO;
        }
    }

    public static int cogerUltimoRegistro(RandomAccessFile rdmFile) throws IOException {
        return (int) Math.ceil((double) rdmFile.length() / TAMANHO_REGISTRO);
    }

    public static boolean comprobarExcedenteFotografo(Fotografo f) {
        int bytes = 0;

        bytes += f.getCodigo();
        bytes += f.getEstudio().length() + 2;
        bytes += f.getNombre().length() + 2;
        bytes += f.getNumLicencia().length() + 2;
        bytes += f.getNumFotografia();

        for (int i = 0; i < f.getNumFotografia(); i++) {
            Fotografia fia = f.getFotografias().get(i);

            bytes += fia.getFechaToma().toString().length() + 2;
            bytes += fia.getTamanoMB();
            bytes += fia.getTipo().length() + 2;
            bytes += fia.getTitulo().length() + 2;
        }

        if (bytes > TAMANHO_REGISTRO) {
            System.out.println("El " + f + "SUPERA EL TAMAÑO PERMITIDO");
            return true;
        }

        return false;
    }

    public static void escribirUTF(RandomAccessFile randomAccessFile, String texto) {
        try {
            randomAccessFile.writeUTF(texto);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void escribirBoolean(RandomAccessFile randomAccessFile, boolean bool) {
        try {
            randomAccessFile.writeBoolean(bool);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public static void escribirInt(RandomAccessFile randomAccessFile, int n) {
        try {
            randomAccessFile.writeInt(n);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static void escribirLocalDate(RandomAccessFile randomAccessFile, LocalDate date) {
        try {
            long fechaLong = Long.valueOf(String.valueOf(date));
            randomAccessFile.writeLong(fechaLong);

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

        public static void escribirDouble(RandomAccessFile randomAccessFile, double n) {
        try {
            randomAccessFile.writeDouble(n);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
