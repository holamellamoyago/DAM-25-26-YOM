package logica;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.ArrayList;

import clases.Fotografia;
import clases.Fotografo;
import excepciones.ArchivoNoExistente;
import persistencia.DatRandomUtils;

public class GestorFotografosRANDOM {
    private RandomAccessFile randomAccessFile;

    public GestorFotografosRANDOM(String ruta) throws ArchivoNoExistente {
        this.randomAccessFile = DatRandomUtils.abrirArchivoRandom(new File(ruta));
    }

    public ArrayList<Fotografo> leerFotografos() {
        ArrayList<Fotografo> fotografos = DatRandomUtils.leerFotografos(randomAccessFile);
        return fotografos;
    }

    public void escribirFotografos(ArrayList<Fotografo> updateFotografos) {
        for (int i = 0; i < updateFotografos.size(); i++) {
            Fotografo f = updateFotografos.get(i);
            escribirFotografo(f);

        }
    }

    public void escribirFotografo(Fotografo f) {
        if (!DatRandomUtils.comprobarExcedenteFotografo(f)) {
            return;
        }

        try {
            f.setCodigo(DatRandomUtils.cogerUltimoRegistro(randomAccessFile) + 1);

            randomAccessFile.seek(DatRandomUtils.cogerSiguientePosicion(randomAccessFile));
            DatRandomUtils.escribirBoolean(randomAccessFile, f.isBorrado());
            DatRandomUtils.escribirInt(randomAccessFile, f.getCodigo());
            DatRandomUtils.escribirUTF(randomAccessFile, f.getNumLicencia());
            DatRandomUtils.escribirUTF(randomAccessFile, f.getNombre());
            DatRandomUtils.escribirUTF(randomAccessFile, f.getEstudio());
            DatRandomUtils.escribirInt(randomAccessFile, f.getNumFotografia());

            for (int i = 0; i < f.getNumFotografia(); i++) {
                Fotografia fia = f.getFotografias().get(i);
                DatRandomUtils.escribirUTF(randomAccessFile, fia.getTitulo());
                DatRandomUtils.escribirLocalDate(randomAccessFile, fia.getFechaToma());
                DatRandomUtils.escribirUTF(randomAccessFile, fia.getTipo());
                DatRandomUtils.escribirDouble(randomAccessFile, fia.getTamanoMB());
            }


            
        } catch (Exception e) {
            return;
        }

    }

}
