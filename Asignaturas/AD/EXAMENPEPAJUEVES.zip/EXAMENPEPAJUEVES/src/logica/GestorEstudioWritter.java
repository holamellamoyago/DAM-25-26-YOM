package logica;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import clases.Fotografo;

public class GestorEstudioWritter {
    private BufferedWriter writter;
    private String ruta;

    // String: estudios, array: los fotografos con ese estudio
    private Map<String, ArrayList<Fotografo>> map = new HashMap<>();

    public GestorEstudioWritter(String ruta) {
        this.ruta = ruta;
    }

    public void escribirFotografosEstudios(ArrayList<Fotografo> fotografos) {
        abrirFichero();

        transformarFotografosEstudio(fotografos);
        escribirInformacion();

        cerrarFichero();
    }

    public void escribirInformacion() {
        final String strGuiones = "-----------------------------------------------------------";

        try {
            Set<Entry<String, ArrayList<Fotografo>>> entries = map.entrySet();

            Iterator<Entry<String, ArrayList<Fotografo>>> it = entries.iterator();
            while (it.hasNext()) {
                Entry<String, ArrayList<Fotografo>> entries2 = it.next();
                String estudio = entries2.getKey();
                ArrayList<Fotografo> fotografos = entries2.getValue();

                writter.newLine();
                writter.write(strGuiones);
                writter.write("\nEstudio: " + estudio);
                writter.newLine();
                writter.write(strGuiones);

                for (Fotografo f : fotografos) {
                    writter.write(f.toStringResumido());
                }
            }

            writter.write(ruta);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void transformarFotografosEstudio(ArrayList<Fotografo> fotografos) {
        for (Fotografo f : fotografos) {
            String estudio = f.getEstudio();

            // Si contiene ya ese estudio, simplemente añade al fotografo
            if (map.containsKey(estudio)) {
                map.get(estudio).add(f);
            } else {
                // Sino crea el estudio y añade a ese fotogrado
                map.put(estudio, new ArrayList<>(List.of(f)));
            }

        }
    }

    public void abrirFichero() {
        try {
            writter = new BufferedWriter(new FileWriter(ruta));
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void cerrarFichero() {
        try {
            writter.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

}
