package excepciones;

public class NoEsArchivo extends Exception{
    public NoEsArchivo() {
        super("La ruta no es un archivo");
    }

}
