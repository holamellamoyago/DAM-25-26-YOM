package excepciones;

public class DirectorioNoExistenteException extends Exception {

    public DirectorioNoExistenteException() {
        super("No existe ese directorio");
    }

}