package excepciones;

import java.io.FileNotFoundException;

public class ArchivoNoExistente extends FileNotFoundException{
    public ArchivoNoExistente() {
        super("No se encuentra el archivo");
    }
    
}
