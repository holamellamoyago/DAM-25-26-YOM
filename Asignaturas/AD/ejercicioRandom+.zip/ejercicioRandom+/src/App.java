import GestorJAXB.GestorAnimales;

public class App {
    public static void main(String[] args) throws Exception {
        GestorAnimales gestorAnimales = new GestorAnimales("zoologico.xml");
        gestorAnimales.getZoologico();
    }
}
