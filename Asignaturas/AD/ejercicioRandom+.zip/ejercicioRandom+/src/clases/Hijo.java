package clases;
import jakarta.xml.bind.annotation.XmlAccessorType;

import jakarta.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class Hijo {
    @XmlAttribute(name = "nombre", required = true)
    private String nombre;

    @XmlAttribute(name = "edad", required = true)
    private int edad;

    public Hijo() {
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

}
