package clases;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class Vaca extends Animal{
    @XmlElement(name = "lecheDiaria")
    private double lecheDiaria;

    public Vaca() {
        super();
    }

    public double getLecheDiaria() {
        return lecheDiaria;
    }

    public void setLecheDiaria(double lecheDiaria) {
        this.lecheDiaria = lecheDiaria;
    }

    

    
    
}
