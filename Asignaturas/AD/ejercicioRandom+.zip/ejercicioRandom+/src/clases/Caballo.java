package clases;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.*;
@XmlAccessorType(XmlAccessType.FIELD)
public class Caballo extends Animal {
    @XmlElement(name = "galope")
    private double galope;

    public Caballo() {
    }

    public double getGalope() {
        return galope;
    }

    public void setGalope(double galope) {
        this.galope = galope;
    }

    
}
