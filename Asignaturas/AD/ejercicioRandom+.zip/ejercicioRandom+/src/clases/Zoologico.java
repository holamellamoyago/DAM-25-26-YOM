package clases;
import java.util.ArrayList;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlElements;
import jakarta.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class Zoologico {

    @XmlAttribute(name = "nombre")
    private String nombreZoo;

    @XmlAttribute(name = "totalAnimales")
    private int totalAnimales;

    @XmlElements({
            @XmlElement(name = "caballo", type = Caballo.class),
            @XmlElement(name = "vaca", type = Vaca.class)
    })

    private ArrayList<Animal> animales;

    public Zoologico() {
        animales = new ArrayList<>();
    }

}