package clases;
import java.time.LocalDate;
import java.util.ArrayList;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;
import jakarta.xml.bind.annotation.XmlSeeAlso;
import jakarta.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

@XmlSeeAlso({
    Vaca.class,
    Caballo.class
})


@XmlAccessorType(XmlAccessType.FIELD)
abstract public class Animal {
    @XmlAttribute(name = "codigo" , required = true)
    private String codigo;

    @XmlAttribute(name = "nombre" , required = true)
    private String nombre;

    @XmlAttribute(name = "edad" , required = true)
    private int edad;

    @XmlAttribute(name = "altura" , required = true)
    private double altura;

    @XmlAttribute(name = "peso" , required = true)
    private float peso;

    @XmlAttribute(name = "ingreso" , required = true)
    @XmlJavaTypeAdapter(LocalDateAdapter.class)
    private LocalDate ingreso;

    @XmlAttribute(name = "vivo" , required = true)
    private boolean vivo;

    @XmlElement(name = "hijos")
    private ArrayList<Hijo> hijos;

    public Animal() {
        hijos = new ArrayList<>();
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }

    public float getPeso() {
        return peso;
    }

    public void setPeso(float peso) {
        this.peso = peso;
    }

    public LocalDate getIngreso() {
        return ingreso;
    }

    public void setIngreso(LocalDate ingreso) {
        this.ingreso = ingreso;
    }

    public boolean isVivo() {
        return vivo;
    }

    public void setVivo(boolean vivo) {
        this.vivo = vivo;
    }

    public ArrayList<Hijo> getHijos() {
        return hijos;
    }

    public void setHijos(ArrayList<Hijo> hijos) {
        this.hijos = hijos;
    }

}
//