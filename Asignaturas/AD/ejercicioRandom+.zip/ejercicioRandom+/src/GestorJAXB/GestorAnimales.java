package GestorJAXB;

import clases.Zoologico;

public class GestorAnimales {
    private String rutaArchivo;

    public GestorAnimales(String rutaArchivo) {
        this.rutaArchivo = rutaArchivo;
    }

    public void getZoologico(){
        Zoologico zoologico =  XMLJAXBUtils.unmarshall(Zoologico.class, "zoologico.xml");
        System.out.println(zoologico);
    }
}
