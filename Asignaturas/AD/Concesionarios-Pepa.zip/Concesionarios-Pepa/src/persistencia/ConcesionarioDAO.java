package persistencia;

import java.sql.*;
import java.sql.Date;
import java.time.LocalDate;
import java.util.*;

import com.mysql.cj.x.protobuf.MysqlxPrepare.Prepare;

import clases.*;
import gestores.*;

public class ConcesionarioDAO {
    private Connection conn;

    public ConcesionarioDAO(Connection conn) {
        this.conn = conn;
    }

    public List<Marca> obtenerMarcasVehiculos() {
        List<Marca> marcas = new ArrayList<>();

        String sql = """
                SELECT * FROM MARCAS
                """;

        try (Statement st = conn.createStatement()) {
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {
                String nombre = rs.getString("Nombre");
                String pais = rs.getString("Pais");

                Marca marca = new Marca();
                marca.setId(rs.getInt("IdMarca"));
                marca.setNombre(nombre);
                marca.setPais(pais);

                marcas.add(marca);
            }

            return marcas;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public boolean comprobarCocheDisponible(int idCoche) {
        String sql = """
                SELECT Estado FROM coches where idCoche = ?
                """;
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, idCoche);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String dispo = rs.getString("Estado");
                if (dispo.equals("Disponible")) {
                    return true;
                }
            }

            return false;

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public int añadirCliente(Cliente cliente) {
        String sql = """
                INSERT INTO Clientes (Nombre, Ciudad, FechaRegistro) VALUES (?,?,?)
                """;

        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, cliente.getNombre());
            ps.setString(2, cliente.getCiudad());
            ps.setDate(3, cliente.getFecha());

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas == 0) {
                throw new SQLException("Inserción fallida, no se afectaron filas.");
            }
            
            ResultSet rs =  ps.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            } 
            
            throw new RuntimeException("Error al coger el id");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        
    }

    
    public int añadirVendedor(Vendedor vendedor) {
        String sql = """
                INSERT INTO Vendedores (Nombre, Zona, Comision) VALUES (?,?,?)
                """;

        try (PreparedStatement ps = conn.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, vendedor.getNombre());
            ps.setString(2, vendedor.getZona());
            ps.setDouble(3, vendedor.getComision());

            int filasAfectadas = ps.executeUpdate();

            if (filasAfectadas == 0) {
                throw new SQLException("Inserción fallida, no se afectaron filas vendedor.");
            }
            
            ResultSet rs =  ps.getGeneratedKeys();
            if (rs.next()) {
                return rs.getInt(1);
            } 
            
            throw new RuntimeException("Error al coger el id");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        
    }

    public Integer comprobarExistenciaCliente(Cliente cliente) {
        String sql = """
                SELECT idCliente, Nombre, Ciudad, FechaRegistro 
                FROM Clientes 
                WHERE Nombre = ? AND FechaRegistro = ? AND Ciudad = ?
                """;
        
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, cliente.getNombre());
                ps.setDate(2, cliente.getFecha());
                ps.setString(3, cliente.getCiudad());

                ResultSet rs =  ps.executeQuery();

                if (rs.next()) {
                    return rs.getInt(1);
                }

                return null;
            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
    }

    public Integer comprobarExistenciaVendedor(Vendedor vendedor) {
        String sql = """
                SELECT idVendedor, Nombre, Zona, Comision 
                FROM Vendedores 
                WHERE Nombre = ? AND Zona = ? AND Comision = ?
                """;
        
            try (PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, vendedor.getNombre());
                ps.setString(2, vendedor.getZona());
                ps.setInt(3, vendedor.getComision());

                ResultSet rs =  ps.executeQuery();

                if (rs.next()) {
                    return rs.getInt(1);
                }

                return null;
            } catch (SQLException e) {
                e.printStackTrace();
                return null;
            }
    }

    public void registrarVentaCoche(int idCoche, int idCliente, int idVendedor, double precioFinal) {
        String sql = """
                INSERT INTO Ventas (idCoche, idCliente, idVendedor, FechaVenta, PrecioFinal) VALUES (?,?,?,?,?)
                """;

        GestorConexion.ejecutarSentencia(conn, sql, idCoche, idCliente, idVendedor, Date.valueOf(LocalDate.now()), precioFinal);
    }

    public void marcarVehiculoComoVendido(int idCoche) {
        String sql = """
                UPDATE coches SET Estado = 'Vendido' WHERE idCoche = ?
                """;

        GestorConexion.ejecutarSentencia(conn, sql, idCoche);
    }

    public void subirComisionVendedor(int id, double d) {
        String sql = """
                {
                    call pr_subidaComision(?,?,?)
                }
                """;

        try (CallableStatement cs = conn.prepareCall(sql)) {
            cs.setInt(1, id);
            cs.setDouble(2, d);
            cs.registerOutParameter(3, Types.DOUBLE);

            if (cs.execute()) {
                double comisionTotal = cs.getDouble(3);
                System.out.println("Subida de comisión completada -> " + comisionTotal);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void obtenerPrecioMaximo() {
        String sql = """
                { ?= CALL fn_obtenerPrecioMaximo(?,?)}
                """;

        try (CallableStatement cs = conn.prepareCall(sql)) {
            cs.registerOutParameter(1, Types.INTEGER);
            cs.setString(2, "a");
            cs.setString(3, "a");

            cs.execute();
            
                System.out.println("Din max -> " + cs.getInt(1));
            
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    public void revisarComisiones() {
        String sql = """
                SELECT Comision FROM Vendedores
                """;
        try (PreparedStatement st = conn.prepareStatement(sql, ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE)) {
            ResultSet rs = st.executeQuery();
            while (rs.next()) {
                if (rs.getDouble(1) < 20.0) {
                    rs.updateDouble(1, 20.0);
                    rs.updateRow();
                }

            }

            
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void añadirMarcaBmwSiNoExiste() {
        // Es fundamental seleccionar las columnas que vas a rellenar
        String sql = "SELECT IdMarca, Nombre, Pais FROM Marcas";
    
        try (PreparedStatement st = conn.prepareStatement(sql, 
                ResultSet.TYPE_SCROLL_SENSITIVE, 
                ResultSet.CONCUR_UPDATABLE)) {
            
            ResultSet rs = st.executeQuery();
            boolean existe = false;
    
            // 1. Buscamos si ya existe BMW
            while (rs.next()) {
                if ("BMW".equalsIgnoreCase(rs.getString("Nombre"))) {
                    existe = true;
                    break;
                }
            }
    
            // 2. Si no existe, usamos el modo inserción
            if (!existe) {
                // Movemos el cursor a la "fila de inserción" (buffer vacío)
                rs.moveToInsertRow();
    
                // Rellenamos las columnas (no rellenamos IdMarca si es IDENTITY)
                rs.updateString("Nombre", "BMW");
                rs.updateString("Pais", "Alemania");
    
                // 3. Insertamos físicamente en la base de datos
                rs.insertRow();
    
                // Opcional: Volvemos a la posición donde estaba el cursor antes
                rs.moveToCurrentRow();
                System.out.println("Marca BMW añadida con éxito.");
            }
    
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}
