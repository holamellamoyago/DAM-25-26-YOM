package logica;

import java.lang.reflect.Array;
import java.time.LocalDate;
import java.util.ArrayList;

import javax.xml.stream.XMLStreamConstants;
import javax.xml.stream.XMLStreamException;
import javax.xml.stream.XMLStreamReader;

import clases.Fotografia;
import clases.Fotografo;
import persistencia.XMLSTAXUtils;

public class GestorFotografosXML {
    private XMLStreamReader reader;

    public GestorFotografosXML(String ruta) {
        reader = XMLSTAXUtils.crearStreamReader(ruta);
    }

    public ArrayList<Fotografo> leerUpdateFotografos() {
        ArrayList<Fotografo> updateFotografos = new ArrayList<>();
        Fotografo fotografo = new Fotografo();

        ArrayList<Fotografia> fotografias = new ArrayList<>();
        Fotografia fotografia = new Fotografia();

        try {
            while (reader.hasNext()) {
                int cursor = reader.next();

                String nombreElemento = "";
                switch (cursor) {
                    case XMLStreamConstants.START_ELEMENT:
                        nombreElemento = XMLSTAXUtils.leerNombreEtiqueta(reader);

                        switch (nombreElemento) {
                            case "Fotografo":
                                fotografo.setNumLicencia(XMLSTAXUtils.leerAtributo(reader, "NumeroLicencia"));
                                break;
                            case "Nombre":
                                fotografo.setNombre(XMLSTAXUtils.leerTexto(reader));
                                break;
                            case "Estudio":
                                fotografo.setEstudio(XMLSTAXUtils.leerTexto(reader));
                                break;
                            case "Fotografia":
                                fotografia.setTipo(XMLSTAXUtils.leerAtributo(reader, "Formato"));
                                fotografia.setFechaToma(LocalDate.parse(XMLSTAXUtils.leerAtributo(reader, "fecha")));
                                fotografia.setTitulo(XMLSTAXUtils.leerTexto(reader));
                                fotografia.setTamanoMB(2);

                                fotografias.add(fotografia);
                                fotografia = new Fotografia();
                                break;
                            default:
                                break;
                        }
                        break;

                    case XMLStreamConstants.END_ELEMENT:
                        nombreElemento = XMLSTAXUtils.leerNombreEtiqueta(reader);

                        switch (nombreElemento) {
                            case "Fotografias":
                                fotografo.setFotografias(fotografias);
                                fotografo.setNumFotografia(fotografias.size());
                                fotografias = new ArrayList<>();
                                break;
                            case "Fotografo":
                                updateFotografos.add(fotografo);
                                fotografo = new Fotografo();
                                break;
                            default:
                                break;
                        }

                        break;

                    default:
                        break;
                }

            }

            return updateFotografos;
        } catch (XMLStreamException e) {
            e.printStackTrace();
            return updateFotografos;
        }

    }

    // private Fotografia leerFotografia() throws XMLStreamException {
    // Fotografia fotografia = new Fotografia();
    // fotografia.setTipo(XMLSTAXUtils.leerAtributo(reader, "Formato"));
    // fotografia.setFechaToma(LocalDate.parse(XMLSTAXUtils.leerAtributo(reader,
    // "fecha")));
    // fotografia.setTitulo(XMLSTAXUtils.leerTexto(reader));
    // fotografia.setTamanoMB(2);

    // return fotografia;
    // }
}
