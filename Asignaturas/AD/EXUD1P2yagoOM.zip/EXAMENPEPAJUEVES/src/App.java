import java.util.ArrayList;

import clases.Fotografo;
import logica.GestorEstudioWritter;
import logica.GestorFotografosRANDOM;
import logica.GestorFotografosXML;

public class App {
    public static void main(String[] args) throws Exception {
        GestorFotografosRANDOM gestorFotografosRANDOM = new GestorFotografosRANDOM("fotografos.dat");
        ArrayList<Fotografo> fotografos = gestorFotografosRANDOM.leerFotografos();
        // System.out.println(fotografos);

        GestorEstudioWritter gestorEstudioWritter = new GestorEstudioWritter("FotografosEstudio.txt");
        gestorEstudioWritter.escribirFotografosEstudios(fotografos);

        System.out.println("A PARTIT DE AQUI EL UPDATE *********************************************");
        GestorFotografosXML gestorFotografosXML = new GestorFotografosXML("UpdateFotografos.xml");
        ArrayList<Fotografo> updateFotografos = gestorFotografosXML.leerUpdateFotografos();
        // System.out.println(updateFotografos);

        // System.out.println(updateFotografos);

        gestorFotografosRANDOM.escribirFotografos(updateFotografos);
        ArrayList<Fotografo> fotografosConUpdate = gestorFotografosRANDOM.leerFotografos();
        System.out.println(fotografosConUpdate);

        System.out.println("Cantidad de fotografos originalmente: " + fotografos.size());
        System.out.println("Cantidad de fotografos UPDATE: " + updateFotografos.size());
        System.out.println("Cantidad de fotografos ORIGINALES Y CON UPDATE: " + fotografosConUpdate.size());

        // System.out.println(gestorFotografosRANDOM2.leerFotografos());

    }
}
