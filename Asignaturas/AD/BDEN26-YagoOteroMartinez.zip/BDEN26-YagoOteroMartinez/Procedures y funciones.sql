SELECT * FROM sys.tables

SELECT * FROM FOTOGRAFO
SELECT * FROM EXPOSICION
SELECT * FROM FOTOGRAFIA
SELECT * FROM ARTISTICA
SELECT* FROM DOCUMENTAL

SELECT * FROM FOTOGRAFIA

--DELETE FOTOGRAFIA WHERE CODIGO = 59

IF OBJECT_ID('fn__ObtenerNumeroFotografias', 'FN') IS NOT NULL
DROP FUNCTION fn__ObtenerNumeroFotografias;
GO

CREATE FUNCTION fn__ObtenerNumeroFotografias(@CodigoFotografo int)
RETURNS INT
AS
BEGIN
	RETURN (SELECT NUMFOTOGRAFIAS FROM FOTOGRAFO WHERE CODIGO = @CodigoFotografo)
END





/*
IF OBJECT_ID('pr_obtenerFotografias', 'P') IS NOT NULL
DROP PROCEDURE pr_obtenerFotografias;

GO
CREATE PROCEDURE pr_obtenerFotografias 
	@NombreExposicion VARCHAR(80),
	@NombreFotografia VARCHAR(50) OUTPUT,
	@TipoFotografia VARCHAR(20) OUTPUT
AS
BEGIN 
	SELECT F.NOME,
	
		IF EXISTS F.CODIGO IN (SELECT * FROM DOCUMENTAL) 
	FROM FOTOGRAFIA F
	INNER JOIN EXPOSICION E ON E.CODIGO = F.COD_EXPOSICION
	WHERE E.NOME = @NombreExposicion


END

*/
GO
IF OBJECT_ID('pt_obtenerLocalidadExposicion', 'P') IS NOT NULL
	DROP PROCEDURE pt_obtenerLocalidadExposicion;

GO
CREATE PROCEDURE pt_obtenerLocalidadExposicion
	@NombreExposicion varchar(80),
	@Localidade VARCHAR(50) OUTPUT
AS
BEGIN

	SELECT @Localidade =  L.NOME + '(' + P.NOME + ')'
	FROM LOCALIDADE L
	INNER JOIN EXPOSICION E ON E.COD_LOCALIDADE = L.CODIGO
	INNER JOIN PROVINCIA P ON P.CODIGO = L.COD_PROVINCIA
	WHERE E.NOME = @NombreExposicion

END



GO
IF OBJECT_ID('pr_obtenerNombreFotografiasNombreFotografo', 'P') IS NOT NULL
	DROP PROCEDURE pr_obtenerNombreFotografiasNombreFotografo;

GO
CREATE PROCEDURE pr_obtenerNombreFotografiasNombreFotografo 
	@NombreExposicion VARCHAR(80)
AS

BEGIN 
	SELECT F.NOME, FO.NOME
	FROM FOTOGRAFIA F 
	INNER JOIN FOTOGRAFO FO ON FO.CODIGO = F.COD_FOTOGRAFO
END
