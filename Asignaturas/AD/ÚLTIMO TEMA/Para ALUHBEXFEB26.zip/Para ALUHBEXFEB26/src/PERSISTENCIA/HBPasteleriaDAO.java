package PERSISTENCIA;


import UTILIDADES.HibernateUtil;
import org.hibernate.Session;

public class HBPasteleriaDAO {

   public static int conectarHibernateDAO() {
        Session sesion = HibernateUtil.getSessionFactory().openSession();
        if (sesion != null) {

            sesion.close();
            return 0;
        } else {
            return -1;
        }
    }
}