
package LOGICA;

import PERSISTENCIA.HBPasteleriaDAO;

public class GestionHBPasteleria {

   public static void comprobarConexion() {
        int resultado = HBPasteleriaDAO.conectarHibernateDAO();

        if (resultado == 0) {
            System.out.println("Conexi�n correcta");

        } else {
            System.out.println("Error de conexi�n ");

        }
    }

}