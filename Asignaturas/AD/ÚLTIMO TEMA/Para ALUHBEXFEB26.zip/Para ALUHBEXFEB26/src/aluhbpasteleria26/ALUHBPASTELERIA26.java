
package aluhbpasteleria26;

import LOGICA.GestionHBPasteleria;

public class ALUHBPASTELERIA26 {  

    public static void main(String[] args) {       
        GestionHBPasteleria.comprobarConexion();

     
    }

    
}
