agenda = [{"yago": "12435"}]

nombre = input("Inserta un nombre: ")
telefono = ""


def existe():
    for i in agenda:
        for j in i:
            if j == nombre:
                return True
        pass
    return False


def actualizartelefono():
    for i in agenda:
        for j in i:
            if j == nombre:
                i[j] = telefono
        pass
    pass


def obtenerTelefono():
    for i in agenda:
        for j in i:
            if j == nombre:
                return str(i[j])
        pass
    pass


def borrarContacto():
    contacto = False

    for i in agenda:
        for j in i:
            if j == nombre:
                contacto = True
        pass

        if contacto:
            agenda.remove(i)
            pass

    pass

def listar():
    for i in agenda:
        for j in i:
            if j == nombre:
                print("El contacto", j , "tiene de numero ", i[j])
        pass
    pass


## Añadir o modificar
if existe():
    telefono = obtenerTelefono()
    letra = input(("El telefono es:", telefono, ",es correcto? (S/N)"))

    if letra == "S":
        print("Logueado correctamente")
        pass
    elif letra == "N":
        telefono = input("Inserte su nuevo telefono")
        actualizartelefono()
        print(("Telefono actualizado a: ", telefono))
        pass
    else:
        print("Letra no existenete")
        pass
else:
    print("")
    telefono = input("El usuairo no esta en la agenda, Dime tu telefono para agregarte: ")
    agenda.append({nombre: telefono})

    print("Usuario agregado", agenda)

## Buscar
print("________________________")
cadeCaracteres = input("Dime una cadena de caracteres: ")
nombresCoinciden = []
for i in agenda:
    for j in i:
        if j.startswith(cadeCaracteres):
            nombresCoinciden.append(j)
            pass
    pass

print("Nombres que coinciden: ", nombresCoinciden)

## Borrar
print("_______________________________")
nombre = input("Dime un nombre")

if existe:
    letra = input("El nombre existe, te gustaría borrarlo? (S/N)")
    if letra == "S":
        borrarContacto()
        pass
    elif letra == "N":
        print("No borrado")
        pass
    else:
        print("Letra no existenete")
        pass

print("Agenda actualziada: ", agenda)


## Listar
print("________________________________________________")
print(listar())

