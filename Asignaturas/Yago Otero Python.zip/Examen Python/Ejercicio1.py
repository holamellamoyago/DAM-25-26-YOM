from pickle import ADDITEMS

asignaturas = {"Matemáticas": 2, "Física": 4, "Ingles": 8, "Lengua": 9, "Gallego": 2, "Plastica": 4, "Tecnología": 7,
              "Quimica": 6, "EF": 9}

for asignatura in asignaturas:
    print(asignatura, "calificación", asignaturas[asignatura])
    pass

notaMaxima=0
asignaturaMaxima =""
notaMinima =100
asignaturaMinima=""

asignaturasSuspensas = 0
asignaturasAprobadas = 0

media = 0
sumaNotas = 0;

for asignatura in asignaturas:
    nota = asignaturas[asignatura]
    sumaNotas += nota

    if nota < 5:
        asignaturasSuspensas +=1
    else:
        asignaturasAprobadas += 1

    if asignaturas[asignatura] > notaMaxima:
        notaMaxima = asignaturas[asignatura]
        asignaturaMaxima = asignatura
        pass

    if asignaturas[asignatura] < notaMinima:
        notaMinima = asignaturas[asignatura]
        asignaturaMinima = asignatura
        pass

print("La", asignaturaMaxima, "tiene la máxima nota", notaMaxima)
print("La", asignaturaMinima, "tiene la mínima nota", notaMinima)
print("El número de asignaturas suspensas es", asignaturasSuspensas)
print("El número de asignaturas aprobadas es", asignaturasAprobadas)
print("La media de las notas es", (sumaNotas / len(asignaturas)))

## Nueva funcionalidad
## Hago la media de las notas suspensas para saber si suspendieron por mucho o poco
sumaTotalNotasSuepnsas =0
totalNotassuspensas =0;
for asignatura in asignaturas:
    nota = asignaturas[asignatura]
    if nota< 5:
        sumaTotalNotasSuepnsas += nota
        totalNotassuspensas += 1
        pass
    pass

print("Media de las asignaturas suspensas", (sumaTotalNotasSuepnsas / totalNotassuspensas))






